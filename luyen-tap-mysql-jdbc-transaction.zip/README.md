# Luyện tập MySQL JDBC Transaction

Bài thực hành tiếp nối ứng dụng WEB quản lý User.

## Nội dung bài
- `IUserDAO.addUserTransaction(User user, int[] permissionIds)`
- Tắt auto-commit bằng `connection.setAutoCommit(false)`
- Thêm User và lấy `GENERATED_KEYS`
- Gán quyền trong cùng một transaction
- `commit()` khi tất cả câu SQL thành công
- `rollback()` khi có `SQLException`

## Trạng thái mặc định để kiểm tra rollback
Trong `UserDAO.addUserTransaction()` tên bảng được **cố tình viết sai** thành `user_permission_BROKEN`.

Vì User đã được INSERT trước khi câu SQL gán quyền bị lỗi, đây là tình huống phù hợp để kiểm tra transaction. Khi lỗi xảy ra, `rollback()` được gọi nên User vừa thêm cũng không được lưu.

## Kiểm tra
1. Sửa `jdbcPassword` trong `UserDAO.java` theo MySQL trên máy.
2. Chạy `database.sql`.
3. Build: `mvn clean package`.
4. Deploy lên Tomcat 10.1+.
5. Mở `http://localhost:8080/user-management/users?action=create`.
6. Nhập User, chọn ít nhất một Permission rồi lưu.
7. Do tên bảng đang cố tình sai, request phát sinh lỗi. Kiểm tra MySQL:

```sql
SELECT * FROM users ORDER BY id DESC;
SELECT * FROM user_permission ORDER BY user_id DESC;
```

Kết quả mong đợi: không có User mới và không có dòng phân quyền mới do transaction đã rollback.

## Kiểm tra commit
Trong `UserDAO.java`, đổi:

```java
String sql="INSERT INTO user_permission_BROKEN (user_id, permission_id) VALUES (?, ?)";
```

thành:

```java
String sql="INSERT INTO user_permission (user_id, permission_id) VALUES (?, ?)";
```

Build/deploy lại và thêm User. Lúc này cả User và các Permission được lưu cùng nhau sau `commit()`.

## Nộp bài
Đưa toàn bộ mã nguồn lên GitHub và nộp link repository.
