package com.codegym.dao;
import com.codegym.model.User;
import java.sql.*; import java.util.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
public class UserDAO implements IUserDAO {
 private final String jdbcURL="jdbc:mysql://localhost:3306/demo?useSSL=false";
 private final String jdbcUsername="root";
 private final String jdbcPassword="password";
 private static final String INSERT="INSERT INTO users(name,email,country) VALUES(?,?,?)";
 private static final String ONE="SELECT id,name,email,country FROM users WHERE id=?";
 private static final String ALL="SELECT * FROM users";
 private static final String DELETE="DELETE FROM users WHERE id=?";
 private static final String UPDATE="UPDATE users SET name=?,email=?,country=? WHERE id=?";
 private static final String SEARCH_COUNTRY="SELECT * FROM users WHERE country LIKE ?";
 private static final String SORT_NAME="SELECT * FROM users ORDER BY name ASC";
 private static final String SQL_INSERT = "INSERT INTO Employee (name, salary, created_Date) VALUES (?,?,?)";
 private static final String SQL_UPDATE = "UPDATE Employee SET salary=? WHERE name=?";
 private static final String SQL_TABLE_CREATE = "CREATE TABLE Employee"
         + "("
         + " id INT(11) AUTO_INCREMENT,"
         + " name VARCHAR(100) NOT NULL,"
         + " salary DECIMAL(15, 2) NOT NULL,"
         + " created_Date TIMESTAMP,"
         + " PRIMARY KEY (id)"
         + ")";
 private static final String SQL_TABLE_DROP = "DROP TABLE IF EXISTS Employee";

 protected Connection getConnection() {
  try { Class.forName("com.mysql.cj.jdbc.Driver"); return DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword); }
  catch(Exception e){ throw new RuntimeException(e); }
 }
 public void insertUser(User u)throws SQLException{
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(INSERT)){p.setString(1,u.getName());p.setString(2,u.getEmail());p.setString(3,u.getCountry());p.executeUpdate();}
 }
 public User selectUser(int id){
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(ONE)){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(r.next())return new User(id,r.getString("name"),r.getString("email"),r.getString("country"));}}
  catch(SQLException e){throw new RuntimeException(e);} return null;
 }
 public List<User> selectAllUsers(){
  List<User> list=new ArrayList<>();
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(ALL);ResultSet r=p.executeQuery()){
   while(r.next())list.add(new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("country")));
  }catch(SQLException e){throw new RuntimeException(e);} return list;
 }
 public boolean deleteUser(int id)throws SQLException{try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(DELETE)){p.setInt(1,id);return p.executeUpdate()>0;}}
 public boolean updateUser(User u)throws SQLException{try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(UPDATE)){p.setString(1,u.getName());p.setString(2,u.getEmail());p.setString(3,u.getCountry());p.setInt(4,u.getId());return p.executeUpdate()>0;}}

 public List<User> searchByCountry(String country){
  List<User> list=new ArrayList<>();
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(SEARCH_COUNTRY)){
   p.setString(1,"%"+country+"%");
   try(ResultSet r=p.executeQuery()){
    while(r.next()) list.add(new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("country")));
   }
  }catch(SQLException e){throw new RuntimeException(e);}
  return list;
 }
 public List<User> sortByName(){
  List<User> list=new ArrayList<>();
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(SORT_NAME);ResultSet r=p.executeQuery()){
   while(r.next()) list.add(new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("country")));
  }catch(SQLException e){throw new RuntimeException(e);}
  return list;
 }
 public User getUserById(int id){
  User user=null;
  String query="{CALL get_user_by_id(?)}";
  try(Connection c=getConnection();CallableStatement cs=c.prepareCall(query)){
   cs.setInt(1,id);
   try(ResultSet r=cs.executeQuery()){
    if(r.next()) user=new User(id,r.getString("name"),r.getString("email"),r.getString("country"));
   }
  }catch(SQLException e){throw new RuntimeException(e);}
  return user;
 }
 public void insertUserStore(User u)throws SQLException{
  String query="{CALL insert_user(?, ?, ?)}";
  try(Connection c=getConnection();CallableStatement cs=c.prepareCall(query)){
   cs.setString(1,u.getName());
   cs.setString(2,u.getEmail());
   cs.setString(3,u.getCountry());
   cs.executeUpdate();
  }
 }
 public void addUserTransaction(User user, int[] permissionIds) throws SQLException {
  Connection connection=null;
  try {
   connection=getConnection();
   connection.setAutoCommit(false);
   String insertUserSql="INSERT INTO users (name, email, country) VALUES (?, ?, ?)";
   int userId;
   try(PreparedStatement ps=connection.prepareStatement(insertUserSql,Statement.RETURN_GENERATED_KEYS)){
    ps.setString(1,user.getName()); ps.setString(2,user.getEmail()); ps.setString(3,user.getCountry());
    ps.executeUpdate();
    try(ResultSet rs=ps.getGeneratedKeys()){
     if(!rs.next()) throw new SQLException("Không lấy được ID của User vừa tạo.");
     userId=rs.getInt(1);
    }
   }
   if(permissionIds!=null && permissionIds.length>0){
    // BÀI LUYỆN TẬP: cố tình dùng sai tên bảng để tạo SQLException và kiểm tra rollback.
    String sql="INSERT INTO user_permission_BROKEN (user_id, permission_id) VALUES (?, ?)";
    // Khi kiểm tra commit thành công, đổi lại thành:
    // String sql="INSERT INTO user_permission (user_id, permission_id) VALUES (?, ?)";
    try(PreparedStatement ps=connection.prepareStatement(sql)){
     for(int permissionId:permissionIds){ ps.setInt(1,userId); ps.setInt(2,permissionId); ps.executeUpdate(); }
    }
   }
   connection.commit();
  } catch(SQLException e){
   if(connection!=null) try{connection.rollback();}catch(SQLException rollbackError){e.addSuppressed(rollbackError);}
   throw e;
  } finally {
   if(connection!=null){ try{connection.setAutoCommit(true);}finally{connection.close();} }
  }
 }

 @Override
 public void insertUpdateWithoutTransaction() throws SQLException {
  try (Connection conn = getConnection();
       Statement statement = conn.createStatement();
       PreparedStatement psInsert = conn.prepareStatement(SQL_INSERT);
       PreparedStatement psUpdate = conn.prepareStatement(SQL_UPDATE)) {
   statement.execute(SQL_TABLE_DROP);
   statement.execute(SQL_TABLE_CREATE);

   psInsert.setString(1, "Quynh");
   psInsert.setBigDecimal(2, new BigDecimal(10));
   psInsert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
   psInsert.execute();

   psInsert.setString(1, "Ngan");
   psInsert.setBigDecimal(2, new BigDecimal(20));
   psInsert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
   psInsert.execute();

   // Cố tình sai: parameter 1 (salary) chưa được gán.
   psUpdate.setBigDecimal(2, new BigDecimal("999.99"));
   psUpdate.setString(2, "Quynh");
   psUpdate.execute();
  } catch (SQLException e) {
   System.out.println("Đã bắt được lỗi trong quá trình thực thi SQL:");
   e.printStackTrace();
  }
 }

 @Override
 public void insertUpdateUseTransaction() throws SQLException {
  Connection conn = null;
  try {
   conn = getConnection();
   try (Statement statement = conn.createStatement()) {
    statement.execute(SQL_TABLE_DROP);
    statement.execute(SQL_TABLE_CREATE);
   }

   conn.setAutoCommit(false);

   try (PreparedStatement psInsert = conn.prepareStatement(SQL_INSERT);
        PreparedStatement psUpdate = conn.prepareStatement(SQL_UPDATE)) {
    psInsert.setString(1, "Quynh");
    psInsert.setBigDecimal(2, new BigDecimal(10));
    psInsert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
    psInsert.execute();

    psInsert.setString(1, "Ngan");
    psInsert.setBigDecimal(2, new BigDecimal(20));
    psInsert.setTimestamp(3, Timestamp.valueOf(LocalDateTime.now()));
    psInsert.execute();

    // LẦN 1 - cố tình sai để kiểm tra rollback:
    psUpdate.setBigDecimal(2, new BigDecimal("999.99"));
    // LẦN 2 - comment dòng trên và mở dòng đúng bên dưới:
    // psUpdate.setBigDecimal(1, new BigDecimal("999.99"));
    psUpdate.setString(2, "Quynh");
    psUpdate.execute();

    conn.commit();
   }
  } catch (SQLException e) {
   if (conn != null) {
    try {
     conn.rollback();
     System.out.println("Có lỗi xảy ra! Transaction đã rollback.");
    } catch (SQLException rollbackError) {
     e.addSuppressed(rollbackError);
    }
   }
   System.out.println("Lỗi xảy ra trong Transaction: " + e.getMessage());
   e.printStackTrace();
  } finally {
   if (conn != null) {
    try { conn.setAutoCommit(true); } catch (SQLException ignored) {}
    conn.close();
   }
  }
 }

}
