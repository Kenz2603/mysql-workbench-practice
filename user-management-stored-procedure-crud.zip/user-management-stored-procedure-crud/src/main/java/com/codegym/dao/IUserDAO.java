package com.codegym.dao;

import com.codegym.model.User;
import java.sql.SQLException;
import java.util.List;

public interface IUserDAO {
    void insertUser(User user) throws SQLException;
    User selectUser(int id);
    List<User> selectAllUsers();
    boolean deleteUser(int id) throws SQLException;
    boolean updateUser(User user) throws SQLException;
    List<User> searchByCountry(String country);
    List<User> sortByName();

    User getUserById(int id);
    void insertUserStore(User user) throws SQLException;
    void addUserTransaction(User user, int[] permissionIds) throws SQLException;
    void insertUpdateWithoutTransaction() throws SQLException;
    void insertUpdateUseTransaction() throws SQLException;

    // Stored Procedures: list / update / delete
    List<User> selectAllUsersStore();
    boolean updateUserStore(User user) throws SQLException;
    boolean deleteUserStore(int id) throws SQLException;
}
