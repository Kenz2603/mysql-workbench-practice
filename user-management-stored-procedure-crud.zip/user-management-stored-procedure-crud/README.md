# Gọi MySQL Stored Procedures từ JDBC

Bài thực hành cập nhật ứng dụng WEB quản lý User để dùng `CallableStatement` cho 3 chức năng:

- Hiển thị danh sách User: `get_all_users()`
- Sửa User: `update_user(?, ?, ?, ?)`
- Xóa User: `delete_user(?)`

Phần hiển thị form Edit tiếp tục dùng Stored Procedure `get_user_by_id(?)` từ bài trước.

## Chạy bài

1. Đổi `jdbcPassword` trong `UserDAO.java` cho đúng MySQL trên máy.
2. Chạy `database.sql` trên database MySQL.
3. Build: `mvn clean package`.
4. Deploy WAR lên Tomcat 10.1+.
5. Mở: `http://localhost:8080/user-management/users`.

## Kiểm tra

- Trang danh sách gọi `selectAllUsersStore()` -> `{CALL get_all_users()}`.
- Submit form Edit gọi `updateUserStore()` -> `{CALL update_user(?, ?, ?, ?)}`.
- Xác nhận Delete gọi `deleteUserStore()` -> `{CALL delete_user(?)}`.

> Lưu ý: `delete_user` xóa các bản ghi `user_permission` trước khi xóa `users` để không vi phạm khóa ngoại từ bài Transaction trước.
