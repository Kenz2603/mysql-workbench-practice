# my-new-project

Dự án thực hành tạo Repository mới trên GitHub và đồng bộ Local Repository với Remote Repository.

## Các câu lệnh Git đã sử dụng

- `git init`: Khởi tạo một Git Repository trong thư mục hiện tại.
- `git remote add origin <repository-url>`: Liên kết Local Repository với Remote Repository trên GitHub và đặt tên remote là `origin`.
- `git add README.md`: Đưa file `README.md` vào vùng staging để chuẩn bị commit.
- `git commit -m "Add README.md file"`: Lưu các thay đổi đã staging vào lịch sử Git với thông điệp mô tả.
- `git push origin main`: Đẩy các commit của nhánh `main` từ Local Repository lên Remote Repository `origin`.

## Repository GitHub

Sau khi tạo và push dự án, dán link Repository của bạn vào đây:

`https://github.com/<username>/my-new-project`
