# BÀI NỘP: TẠO DỰ ÁN MỚI TRÊN GITHUB

## Ý nghĩa các câu lệnh

`git init`: Khởi tạo Local Repository trong thư mục dự án.

`git remote add origin <repository-url>`: Kết nối Local Repository với Remote Repository trên GitHub, với tên remote là `origin`.

`git add README.md`: Đưa file README.md vào vùng staging.

`git commit -m "Add README.md file"`: Tạo commit lưu lại thay đổi và gắn thông điệp mô tả.

`git push origin main`: Đẩy các commit trên nhánh main lên Remote Repository có tên origin.

## Link Repository

https://github.com/<username>/my-new-project
