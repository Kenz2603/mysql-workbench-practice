# User Management - JDBC Transaction

Bài thực hành nâng cấp User Management sử dụng JDBC Transaction.

## Nội dung
- Thêm bảng `permission` và `user_permission`.
- Form tạo User cho phép chọn nhiều quyền.
- `addUserTransaction()` tắt auto-commit, thêm User, lấy generated key, thêm quyền và `commit()`.
- Nếu một thao tác lỗi, toàn bộ transaction được `rollback()`.
- Giữ các chức năng Stored Procedure và CRUD từ bài trước.

## Chạy
1. Đổi `jdbcPassword` trong `UserDAO.java` theo MySQL trên máy.
2. Chạy `database.sql` trên database `demo`.
3. Chạy `mvn clean package`.
4. Deploy WAR lên Tomcat 10.1+.
5. Mở `http://localhost:8080/user-management/users?action=create`.

## Kiểm tra
```sql
SELECT * FROM users ORDER BY id DESC LIMIT 1;
SELECT * FROM user_permission;
```
