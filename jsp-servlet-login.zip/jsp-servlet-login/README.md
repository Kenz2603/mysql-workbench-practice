# jsp-servlet-login

Bài thực hành Java Web: đăng nhập và hiển thị lời chào.

## Tài khoản kiểm thử
- Username: `admin`
- Password: `admin`

Đăng nhập đúng hiển thị: `Welcome admin to website`.
Đăng nhập sai hiển thị: `Login Error`.

## Công nghệ
- Java 17
- Maven
- Jakarta Servlet API 6.0
- JSP API 3.1.1
- Tomcat 10.1+

## Build
```bash
mvn clean package
```

Khi Maven báo `BUILD SUCCESS`, file deploy được tạo tại:

`target/jsp-servlet-login.war`

## Chạy trên Tomcat
Sau khi deploy WAR, truy cập:

`http://localhost:8080/jsp-servlet-login/`
