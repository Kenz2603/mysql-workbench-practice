# Bài thực hành: Tạo menu dọc

## File
- `index.html`
- `styles.css`

## Chức năng
Menu dọc gồm Sem 1, Sem 2, Sem 3 và Sem 4.

Khi đưa chuột vào Sem 1 hoặc Sem 2, menu con được hiển thị ở bên phải.
Mục menu đổi nền sang màu đỏ khi hover.

CSS được tách thành file `styles.css` và nhúng bằng thẻ `<link>`.
