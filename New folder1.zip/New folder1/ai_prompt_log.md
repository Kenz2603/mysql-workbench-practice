# AI Prompt Log – PayFlow

## Prompt 1 – YEAR/MONTH và Index

**Prompt:**  
Trong MySQL, nếu tôi tạo index cho một cột ngày tháng nhưng viết `WHERE YEAR(created_at) = 2026`, vì sao Optimizer có thể không dùng B-Tree Index theo kiểu range?

**Kết luận áp dụng:**  
Hàm bao quanh cột làm điều kiện không còn SARGable theo giá trị gốc của `created_at`. Nên chuyển sang so sánh trực tiếp bằng khoảng thời gian.

## Prompt 2 – SARGable

**Prompt:**  
Thuật ngữ SARGable trong SQL nghĩa là gì và vì sao điều kiện `created_at >= ... AND created_at < ...` phù hợp với B-Tree Index hơn `YEAR()` và `MONTH()`?

**Kết luận áp dụng:**  
Điều kiện SARGable cho phép hệ quản trị dùng index để xác định vùng dữ liệu cần tìm thay vì tính hàm cho từng dòng.

## Prompt 3 – Thứ tự Composite Index

**Prompt:**  
Với truy vấn có `transaction_type = 'DEPOSIT'` và một khoảng `created_at`, thứ tự index `(transaction_type, created_at)` có hợp lý không?

**Kết luận áp dụng:**  
Có. Điều kiện bằng trên cột đầu và điều kiện range trên cột sau phù hợp với quy tắc left-most prefix của B-Tree.

## Prompt 4 – EXPLAIN type

**Prompt:**  
Các giá trị `ALL`, `index`, `range`, `ref`, `const` trong cột `type` của MySQL EXPLAIN thể hiện điều gì?

**Kết luận áp dụng:**  
`ALL` là full table scan; `range` truy cập một vùng index; `ref` tra cứu theo giá trị không duy nhất; `const` thường là tra cứu rất chọn lọc theo khóa duy nhất.

## Prompt 5 – EXPLAIN ANALYZE

**Prompt:**  
Trong MySQL 8, làm thế nào xem thời gian thực thi thực tế thay vì chỉ xem kế hoạch ước lượng?

**Kết luận áp dụng:**  
Dùng `EXPLAIN ANALYZE` trên MySQL 8.0.18+ để xem số dòng và thời gian thực tế của các bước thực thi.

## Prompt 6 – Using index condition và Using index

**Prompt:**  
Trong cột `Extra` của EXPLAIN, `Using index condition` khác `Using index` như thế nào?

**Kết luận áp dụng:**  
`Using index condition` thường liên quan Index Condition Pushdown; `Using index` cho biết truy vấn có thể được phục vụ từ index mà không cần đọc đầy đủ dòng bảng trong trường hợp covering index.

## Prompt 7 – Index Seek và Index Scan

**Prompt:**  
Khác biệt giữa Index Seek và Index Scan là gì, và B-Tree giúp tìm kiếm theo khoảng như thế nào?

**Kết luận áp dụng:**  
Seek định vị vùng index cần thiết rồi đọc các khóa phù hợp; Scan đọc một phần lớn hoặc toàn bộ index. B-Tree hỗ trợ tìm điểm bắt đầu hiệu quả rồi duyệt tuần tự theo range.
