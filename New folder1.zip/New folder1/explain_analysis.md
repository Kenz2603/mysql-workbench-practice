# EXPLAIN Analysis – PayFlow

Truy vấn cũ dùng `YEAR(created_at)` và `MONTH(created_at)`, làm điều kiện trở thành **Non-SARGable**. Khi đó MySQL khó dùng B-Tree Index để tìm trực tiếp một khoảng thời gian và thường phải quét rất nhiều dòng; trên bảng lớn, `EXPLAIN` có thể cho `type = ALL`, `key = NULL` và `rows` gần với tổng số bản ghi.

Sau khi tạo composite index `idx_type_date(transaction_type, created_at)` và viết lại điều kiện thành `created_at >= '2026-06-01' AND created_at < '2026-07-01'`, truy vấn trở thành **SARGable**. MySQL có thể lọc theo `transaction_type` rồi quét một dải thời gian liên tục trong B-Tree. Với dữ liệu lớn, `type` thường chuyển sang `range` hoặc `ref`, cột `key` có thể hiển thị `idx_type_date`, và số `rows` ước lượng giảm đáng kể.

Lưu ý: trên bảng thử nghiệm rất nhỏ, Optimizer vẫn có thể chọn `ALL` vì quét toàn bảng rẻ hơn dùng index.
