-- ============================================================
-- PAYFLOW - QUERY OPTIMIZATION WITH EXPLAIN & INDEX
-- File: payflow_optimized.sql
-- MySQL 8.x
-- ============================================================

DROP DATABASE IF EXISTS payflow_db;
CREATE DATABASE payflow_db;
USE payflow_db;

-- ------------------------------------------------------------
-- 1. CẤU TRÚC LEGACY
-- ------------------------------------------------------------

CREATE TABLE Transactions (
    transaction_id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT,
    amount DECIMAL(15,2) NOT NULL,
    transaction_type VARCHAR(20) NOT NULL,
    created_at DATETIME NOT NULL
);

-- ------------------------------------------------------------
-- 2. DỮ LIỆU MẪU NHỎ ĐỂ KIỂM TRA LOGIC
-- Trong hệ thống thực tế bảng có thể chứa hàng triệu dòng.
-- ------------------------------------------------------------

INSERT INTO Transactions (user_id, amount, transaction_type, created_at) VALUES
(1, 100000.00, 'DEPOSIT',  '2026-06-01 08:00:00'),
(2, 250000.00, 'DEPOSIT',  '2026-06-05 10:15:00'),
(3,  50000.00, 'WITHDRAW', '2026-06-07 11:20:00'),
(4, 400000.00, 'DEPOSIT',  '2026-06-20 14:30:00'),
(5, 150000.00, 'TRANSFER', '2026-06-22 09:45:00'),
(6, 300000.00, 'DEPOSIT',  '2026-05-28 16:00:00'),
(7, 500000.00, 'DEPOSIT',  '2026-07-02 13:10:00');

-- ------------------------------------------------------------
-- 3. EXPLAIN TRUY VẤN CŨ - NON-SARGABLE
-- YEAR() và MONTH() bọc quanh created_at khiến B-Tree index
-- trên created_at không thể được tận dụng hiệu quả theo range.
-- ------------------------------------------------------------

EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND YEAR(created_at) = 2026
  AND MONTH(created_at) = 6;

-- ------------------------------------------------------------
-- 4. TẠO COMPOSITE INDEX
-- transaction_type: điều kiện so sánh bằng (=)
-- created_at: điều kiện khoảng thời gian (range)
-- ------------------------------------------------------------

CREATE INDEX idx_type_date
ON Transactions (transaction_type, created_at);

ANALYZE TABLE Transactions;

-- ------------------------------------------------------------
-- 5. EXPLAIN TRUY VẤN ĐÃ TỐI ƯU - SARGABLE
-- Dùng khoảng nửa mở [2026-06-01, 2026-07-01)
-- để bao phủ toàn bộ tháng 06/2026 mà không dùng hàm trên cột.
-- ------------------------------------------------------------

EXPLAIN
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- ------------------------------------------------------------
-- 6. TRUY VẤN BÁO CÁO THỰC TẾ
-- ------------------------------------------------------------

SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- Kết quả với dữ liệu mẫu: 750000.00

-- ------------------------------------------------------------
-- 7. XEM INDEX ĐÃ TẠO
-- ------------------------------------------------------------

SHOW INDEX FROM Transactions;

-- ------------------------------------------------------------
-- 8. TÙY CHỌN: ĐO THỜI GIAN THỰC THI CHI TIẾT
-- MySQL 8.0.18+ hỗ trợ EXPLAIN ANALYZE.
-- ------------------------------------------------------------

EXPLAIN ANALYZE
SELECT SUM(amount) AS total_deposit
FROM Transactions
WHERE transaction_type = 'DEPOSIT'
  AND created_at >= '2026-06-01 00:00:00'
  AND created_at <  '2026-07-01 00:00:00';

-- Lưu ý:
-- Với bảng mẫu rất nhỏ, MySQL Optimizer đôi khi có thể chọn quét bảng
-- vì chi phí thấp hơn dùng index. Trên bảng lớn, truy vấn SARGable cùng
-- idx_type_date thường cho phép access type dạng range/ref và giảm mạnh rows.
