package com.codegym.controller;
import com.codegym.dao.UserDAO; import com.codegym.model.User;
import jakarta.servlet.*; import jakarta.servlet.annotation.WebServlet; import jakarta.servlet.http.*;
import java.io.IOException;
@WebServlet(name="UserServlet",urlPatterns="/users")
public class UserServlet extends HttpServlet {
 private UserDAO dao;
 public void init(){dao=new UserDAO();}
 protected void doGet(HttpServletRequest q,HttpServletResponse s)throws ServletException,IOException{
  String a=q.getParameter("action"); if(a==null)a="";
  try{switch(a){case "create"->forward(q,s,"/user/create.jsp");case "edit"->{q.setAttribute("user",dao.selectUser(Integer.parseInt(q.getParameter("id"))));forward(q,s,"/user/edit.jsp");}case "delete"->{q.setAttribute("user",dao.selectUser(Integer.parseInt(q.getParameter("id"))));forward(q,s,"/user/delete.jsp");}case "search"->{q.setAttribute("listUser",dao.searchByCountry(q.getParameter("country")));forward(q,s,"/user/list.jsp");}case "sort"->{q.setAttribute("listUser",dao.sortByName());forward(q,s,"/user/list.jsp");}default->{q.setAttribute("listUser",dao.selectAllUsers());forward(q,s,"/user/list.jsp");}}}
  catch(Exception e){throw new ServletException(e);}
 }
 protected void doPost(HttpServletRequest q,HttpServletResponse s)throws ServletException,IOException{
  q.setCharacterEncoding("UTF-8"); String a=q.getParameter("action");
  try{
   if("create".equals(a))dao.insertUser(new User(q.getParameter("name"),q.getParameter("email"),q.getParameter("country")));
   else if("edit".equals(a))dao.updateUser(new User(Integer.parseInt(q.getParameter("id")),q.getParameter("name"),q.getParameter("email"),q.getParameter("country")));
   else if("delete".equals(a))dao.deleteUser(Integer.parseInt(q.getParameter("id")));
   s.sendRedirect(q.getContextPath()+"/users");
  }catch(Exception e){throw new ServletException(e);}
 }
 private void forward(HttpServletRequest q,HttpServletResponse s,String path)throws ServletException,IOException{q.getRequestDispatcher(path).forward(q,s);}
}