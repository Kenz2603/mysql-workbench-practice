# Cập nhật ứng dụng quản lý User

Bổ sung:
- Tìm kiếm User theo `country`
- Sắp xếp User theo `name`

Công nghệ: JSP, Servlet, JDBC, MySQL, Maven, Tomcat 10.1+.

## Chạy
1. Dùng CSDL `demo` và bảng `users` của bài trước.
2. Sửa tài khoản MySQL trong `UserDAO.java`.
3. `mvn clean package`
4. Deploy `target/user-management.war`
5. Mở `http://localhost:8080/user-management/users`

## Chức năng mới
- Tìm kiếm: `/users?action=search&country=Viet`
- Sắp xếp: `/users?action=sort`
