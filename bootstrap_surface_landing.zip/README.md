# Xây dựng Landing Page bằng Bootstrap

Bài thực hành mô phỏng phong cách Landing Page của dòng Microsoft Surface.

## Bootstrap components/utilities đã dùng
- Navbar + responsive collapse
- Container, Row, Grid columns
- Buttons
- Badges
- Cards
- Accordion
- Responsive utilities
- Spacing, typography, colors, shadows, borders

## Responsive
Trang tự điều chỉnh trên Desktop, Tablet và Mobile nhờ Bootstrap Grid.

## Chạy bài
Mở `index.html` bằng trình duyệt hoặc Live Server.

> Đây là bài thực hành học tập, không phải trang chính thức của Microsoft.
> Ảnh minh họa được tải từ Unsplash qua URL nên cần Internet để hiển thị.
