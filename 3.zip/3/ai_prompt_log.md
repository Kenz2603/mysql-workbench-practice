# AI Prompt Log – SmartFactory

## Prompt 1 – Covering Index
**Prompt:** Covering Index trong MySQL là gì và tại sao nó có thể làm SELECT nhanh hơn?

**Kết quả tra cứu:** Khi index chứa đủ các cột cần cho điều kiện và kết quả truy vấn, MySQL có thể phục vụ truy vấn từ index mà không cần lấy thêm các cột từ bản ghi gốc. Điều này có thể giảm I/O đọc.

## Prompt 2 – Clustered và Secondary Index
**Prompt:** InnoDB tổ chức Clustered Index và Secondary Index như thế nào?

**Kết quả tra cứu:** InnoDB tổ chức dữ liệu bảng theo clustered index, thường dựa trên primary key. Secondary index là các B+Tree riêng và chứa khóa secondary cùng thông tin cần thiết để xác định bản ghi clustered index. Vì vậy index phụ càng rộng thì càng tiêu tốn storage và cache.

## Prompt 3 – Write Penalty
**Prompt:** Tại sao thêm nhiều cột vào composite secondary index có thể làm INSERT chậm hơn?

**Kết quả tra cứu:** Entry index lớn hơn làm giảm số entry chứa được trên mỗi page, tăng số page cần quản lý và lượng dữ liệu phải ghi. Mỗi INSERT cũng phải duy trì các secondary index liên quan.

## Prompt 4 – Byte calculation
**Prompt:** Hãy phân tích tương đối kích thước các cột INT, DATETIME, DECIMAL(5,2) và VARCHAR(20) trong MySQL để giải thích tại sao bỏ temperature, humidity và status khỏi index giúp index nhỏ hơn.

**Kết quả tra cứu:** Mỗi cột bổ sung làm tăng độ rộng của index entry. INT có kích thước cố định nhỏ; DATETIME và DECIMAL có cách lưu trữ nhị phân riêng; VARCHAR cần dữ liệu ký tự cùng phần quản lý độ dài. Kích thước chính xác còn phụ thuộc charset, phiên bản MySQL, giá trị thực tế và overhead của InnoDB, nên báo cáo nên dựa vào `INDEX_LENGTH` đo thực tế thay vì suy ra một tỷ lệ tiết kiệm cố định.

## Prompt 5 – VARCHAR status và TINYINT
**Prompt:** Nếu đổi status từ VARCHAR(20) thành TINYINT thì Data Length và Index Length có thể thay đổi thế nào?

**Kết quả tra cứu:** Với mã trạng thái nhỏ, TINYINT thường cần ít byte hơn chuỗi VARCHAR. Điều này có thể giảm Data Length và, nếu cột nằm trong index, giảm độ rộng index entry. Tuy nhiên mức tiết kiệm thực tế phải đo trên dữ liệu thật.
