# Index Trade-off Report – SmartFactory

## Chẩn đoán

`idx_fat_covering(sensor_id, recorded_at, temperature, humidity, status)` giúp truy vấn Dashboard có thể trở thành covering query vì các cột cần lọc và trả về đều nằm trong secondary index. Lợi ích là giảm nhu cầu lookup bản ghi gốc. Tuy nhiên, với hệ thống IoT có tốc độ ghi rất cao, index rộng làm mỗi entry lớn hơn, cần nhiều index pages hơn và tăng chi phí I/O, cache và bảo trì B+Tree khi liên tục INSERT.

Giải pháp là xóa `idx_fat_covering` và tạo `idx_lean_search(sensor_id, recorded_at)`. Hai cột này phù hợp với điều kiện `sensor_id = ...` và khoảng thời gian `recorded_at >= ...`. Sau thay đổi, MySQL vẫn có thể dùng index để thu hẹp tập bản ghi, nhưng phải lookup dữ liệu gốc để lấy `temperature`, `humidity` và `status`.

Đây là đánh đổi có chủ đích: giảm lợi thế đọc của covering index để giảm kích thước secondary index và chi phí ghi. Mức cải thiện thực tế không nên giả định là “INSERT nhanh 5 lần” hay “giảm 70%” nếu chưa benchmark trên dữ liệu thật.

## Kết quả đo thực tế

| Chỉ số | Trước | Sau |
|---|---:|---:|
| Data Length (MB) | ____ | ____ |
| Index Length (MB) | ____ | ____ |
| Total (MB) | ____ | ____ |
| EXPLAIN key | idx_fat_covering | idx_lean_search |
| EXPLAIN type | ____ | ____ |
| EXPLAIN Extra | ____ | ____ |

Điền các ô trống bằng kết quả MySQL thực tế sau khi chạy script.
