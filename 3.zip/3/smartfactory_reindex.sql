-- SMARTFACTORY - REINDEX OPTIMIZATION
-- Muc tieu: thay Fat Covering Index bang Lean Index

USE smartfactory_db;

-- 1. Kiem tra index va dung luong truoc toi uu
SHOW INDEX FROM SensorLogs;
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'smartfactory_db'
  AND TABLE_NAME = 'SensorLogs';

-- 2. EXPLAIN voi Fat Covering Index
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105
  AND recorded_at >= '2026-06-20';

-- 3. Loai bo Fat Index
ALTER TABLE SensorLogs
DROP INDEX idx_fat_covering;

-- 4. Tao Lean Index chi gom cac cot phuc vu loc/range
CREATE INDEX idx_lean_search
ON SensorLogs(sensor_id, recorded_at);

ANALYZE TABLE SensorLogs;

-- 5. Kiem tra index moi
SHOW INDEX FROM SensorLogs;

-- 6. EXPLAIN sau toi uu
EXPLAIN
SELECT temperature, humidity, status
FROM SensorLogs
WHERE sensor_id = 105
  AND recorded_at >= '2026-06-20';

-- Ky vong:
-- key: idx_lean_search
-- type: range hoac ref tuy du lieu/thong ke
-- Extra khong con "Using index" theo nghia covering index,
-- vi temperature, humidity, status khong nam trong idx_lean_search.

-- 7. Kiem tra dung luong sau toi uu
SHOW TABLE STATUS LIKE 'SensorLogs';

SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'smartfactory_db'
  AND TABLE_NAME = 'SensorLogs';

-- Luu y:
-- Khong tu ket luan % tiet kiem hay toc do INSERT neu chua benchmark.
-- Hay ghi lai Index_length va EXPLAIN thuc te truoc/sau.
