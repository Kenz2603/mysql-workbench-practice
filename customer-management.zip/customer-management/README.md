# Ứng dụng quản lý khách hàng

Bài thực hành Java Web theo mô hình MVC.

## Công nghệ
- Java 17
- Maven Webapp
- Jakarta Servlet 6
- JSP / JSTL 3
- Tomcat 10.1+

## Chức năng
- Hiển thị danh sách khách hàng
- Thêm khách hàng
- Sửa khách hàng
- Xóa khách hàng
- Xem chi tiết khách hàng

## Build
```bash
mvn clean package
```

File WAR được tạo tại:
`target/customer-management.war`

## Chạy
Deploy WAR lên Tomcat 10.1+ và truy cập:
`http://localhost:8080/customer-management/customers`
