<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<!DOCTYPE html><html><head><title>Xác nhận xóa</title><meta charset="UTF-8">
<style>
body{font-family:Arial,sans-serif;margin:30px;background:#f8fafc;color:#333}
.container{max-width:900px;margin:auto;background:white;padding:28px;border-radius:8px;box-shadow:0 4px 10px #00000015}
h1,h2{color:#1b2a7a} table{border-collapse:collapse;width:100%} th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left}
th{background:#1b2a7a;color:white}.btn{display:inline-block;padding:8px 14px;text-decoration:none;border-radius:4px;margin:3px}
.create{background:#27ae60;color:white}.edit{color:#2980b9}.delete{color:#c0392b}.view{color:#1b2a7a}
input{width:100%;padding:10px;margin:6px 0 14px;box-sizing:border-box}.submit{background:#1b2a7a;color:white;border:0;padding:11px 18px;border-radius:4px;cursor:pointer}
.message{background:#e8f5e9;color:#207a3c;padding:10px;margin-bottom:15px}.back{display:inline-block;margin-top:18px}
</style></head>
<body><div class="container">
<h2>XÁC NHẬN XÓA KHÁCH HÀNG</h2>
<p>Bạn có chắc chắn muốn xóa khách hàng sau khỏi danh sách hệ thống?</p>
<p><strong>Họ và tên:</strong> ${requestScope.customer.name}<br>
<strong>Email:</strong> ${requestScope.customer.email}</p>
<form action="${pageContext.request.contextPath}/customers?action=delete" method="post">
<input type="hidden" name="id" value="${requestScope.customer.id}">
<button class="submit" type="submit">Đồng ý xóa</button>
<a class="btn" href="${pageContext.request.contextPath}/customers">Hủy bỏ</a>
</form></div></body></html>
