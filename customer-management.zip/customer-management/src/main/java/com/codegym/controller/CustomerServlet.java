package com.codegym.controller;

import com.codegym.model.Customer;
import com.codegym.service.CustomerService;
import com.codegym.service.CustomerServiceImpl;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.List;

@WebServlet(name = "CustomerServlet", urlPatterns = "/customers")
public class CustomerServlet extends HttpServlet {
    private final CustomerService customerService = new CustomerServiceImpl();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        if (action == null) action = "";

        switch (action) {
            case "create" -> showCreateForm(request, response);
            case "edit" -> showEditForm(request, response);
            case "delete" -> showDeleteForm(request, response);
            case "view" -> viewCustomer(request, response);
            default -> listCustomers(request, response);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        if (action == null) action = "";

        switch (action) {
            case "create" -> createCustomer(request, response);
            case "edit" -> updateCustomer(request, response);
            case "delete" -> deleteCustomer(request, response);
            default -> response.sendRedirect(request.getContextPath() + "/customers");
        }
    }

    private void listCustomers(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        List<Customer> customers = customerService.findAll();
        request.setAttribute("customers", customers);
        request.getRequestDispatcher("/customer/list.jsp").forward(request, response);
    }

    private void showCreateForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("/customer/create.jsp").forward(request, response);
    }

    private void showEditForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Customer customer = findCustomer(request);
        forwardCustomerOr404(customer, "/customer/edit.jsp", request, response);
    }

    private void showDeleteForm(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Customer customer = findCustomer(request);
        forwardCustomerOr404(customer, "/customer/delete.jsp", request, response);
    }

    private void viewCustomer(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Customer customer = findCustomer(request);
        forwardCustomerOr404(customer, "/customer/view.jsp", request, response);
    }

    private void createCustomer(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String name = request.getParameter("name");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        int id = (int) (Math.random() * 10000);

        customerService.save(new Customer(id, name, email, address));
        request.setAttribute("message", "New customer was created");
        request.getRequestDispatcher("/customer/create.jsp").forward(request, response);
    }

    private void updateCustomer(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Customer customer = findCustomer(request);
        if (customer == null) {
            request.getRequestDispatcher("/error-404.jsp").forward(request, response);
            return;
        }

        customer.setName(request.getParameter("name"));
        customer.setEmail(request.getParameter("email"));
        customer.setAddress(request.getParameter("address"));
        customerService.update(customer.getId(), customer);

        request.setAttribute("customer", customer);
        request.setAttribute("message", "Customer information was updated");
        request.getRequestDispatcher("/customer/edit.jsp").forward(request, response);
    }

    private void deleteCustomer(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        Customer customer = findCustomer(request);
        if (customer == null) {
            request.getRequestDispatcher("/error-404.jsp").forward(request, response);
            return;
        }

        customerService.remove(customer.getId());
        response.sendRedirect(request.getContextPath() + "/customers");
    }

    private Customer findCustomer(HttpServletRequest request) {
        try {
            return customerService.findById(Integer.parseInt(request.getParameter("id")));
        } catch (NumberFormatException e) {
            return null;
        }
    }

    private void forwardCustomerOr404(Customer customer, String page,
                                      HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        if (customer == null) {
            request.getRequestDispatcher("/error-404.jsp").forward(request, response);
            return;
        }
        request.setAttribute("customer", customer);
        request.getRequestDispatcher(page).forward(request, response);
    }
}
