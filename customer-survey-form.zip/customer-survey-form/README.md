# Customer Survey Form
Form khảo sát khách hàng theo mẫu Market Research Survey.

## Chạy
Mở `index.html` bằng trình duyệt.

## Nộp bài
Đưa `index.html`, `style.css` và `README.md` lên GitHub, chụp màn hình kết quả rồi nộp link Repository trên CodeGymX.
