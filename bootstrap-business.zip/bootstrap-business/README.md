# Trang Giới Thiệu Doanh Nghiệp với Bootstrap

Bài thực hành Bootstrap 5.3.0 gồm Navbar, Hero Section, About, Services (Grid System và Cards), Contact và Footer.

## Chạy dự án

Mở `index.html` bằng Chrome, Edge hoặc Firefox. Cần có kết nối Internet để tải Bootstrap qua CDN.

## Các thành phần Bootstrap

- Navbar: `navbar`, `navbar-expand-lg`, `navbar-toggler`, `collapse`
- Hero: `bg-primary`, `text-white`, `text-center`, `py-5`, `btn`
- About: `container`, `row`, `col-lg-9`
- Services: `row`, `col-md-4`, `card`, `g-4`
- Contact: `container`, `py-5`, `text-center`
- Footer: `bg-dark`, `text-white`

## Nộp bài

1. Mở `index.html`, kiểm tra menu và các phần nội dung ở màn hình desktop/mobile.
2. Đưa toàn bộ thư mục lên GitHub Repository.
3. Dán link Repository lên CodeGym.

Thông tin công ty, email và hotline trong trang là dữ liệu minh họa.
