# JSP Currency Converter

Ứng dụng JSP chuyển đổi USD sang VNĐ theo tỉ giá nhập từ form.

## Yêu cầu
- Java 17
- Maven
- Tomcat 10.1+

## Build
```bash
mvn clean package
```

File WAR: `target/jsp-currency-converter.war`

## Chạy
Deploy WAR lên Tomcat và truy cập:
`http://localhost:8080/jsp-currency-converter/`
