# AI Prompt Log

## 1. CSS Grid và Mosaic
**Prompt:** Làm thế nào dùng CSS Grid để tạo một ảnh lớn bên trái chiếm 2 hàng và 2 ảnh nhỏ bên phải?

**Kết luận:** Dùng 2 cột `2fr 1fr`, hai hàng và đặt ảnh chính `grid-row: span 2`.

## 2. Absolute Positioning
**Prompt:** Vì sao `position: absolute` dễ gây đè nội dung trong responsive layout?

**Kết luận:** Phần tử absolute ra khỏi normal flow nên cha không tự lấy chiều cao của nó; tọa độ cố định cũng khó thích ứng màn hình nhỏ.

## 3. Bootstrap Breakpoints
**Prompt:** Làm sao để 4 card thành 4 cột desktop, 2 cột tablet và 1 cột mobile?

**Kết luận:** Dùng `col-12 col-md-6 col-lg-3`.

## 4. Bootstrap Utilities
**Prompt:** Các utility nào có thể giảm CSS thủ công cho căn chỉnh và khoảng cách?

**Kết luận:** Có thể dùng `d-flex`, `align-items-center`, `justify-content-between`, `gap-*`, `mt-*`, `mb-*`, `py-*`.

## 5. Flexbox Author Info
**Prompt:** Làm sao để cụm tác giả và nút Share căn giữa dọc nhưng vẫn xuống dòng trên mobile?

**Kết luận:** Dùng Flexbox với `align-items: center`, `justify-content: space-between`, `flex-wrap: wrap` và `gap`.
