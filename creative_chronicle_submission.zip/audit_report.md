# Legacy Layout Audit

1. **Author Info:** `float` không được thiết kế cho căn chỉnh component UI theo trục; phải dùng clearfix/overflow để cha ôm các phần tử float. Thay bằng Flexbox.
2. **Mosaic Gallery:** `position: absolute` cùng chiều cao 400px đưa ảnh ra khỏi normal flow và phụ thuộc kích thước cố định, dễ đè nội dung trên mobile. Thay bằng CSS Grid.
3. **Recommended Articles:** `float: left` + `width: 23%` tạo breakpoint thủ công và dễ rớt dòng sai. Thay bằng Bootstrap `col-12 col-md-6 col-lg-3`.
