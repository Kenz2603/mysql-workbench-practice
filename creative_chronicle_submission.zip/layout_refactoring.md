# Layout Refactoring

`position: absolute` gây khó khăn cho responsive layout vì phần tử bị đưa ra khỏi normal flow. Phần tử cha không còn tự tăng chiều cao theo nội dung, nên khi màn hình thay đổi kích thước, các ảnh có thể chồng lên văn bản hoặc lên nhau. Việc gán tọa độ và chiều cao pixel cố định còn khiến giao diện phụ thuộc mạnh vào một kích thước màn hình cụ thể.

CSS Grid phù hợp hơn cho Mosaic Gallery vì nó quản lý đồng thời hàng và cột trong normal flow. Ảnh chính có thể chiếm hai hàng bằng `grid-row: span 2`, trong khi hai ảnh nhỏ tự nằm ở cột còn lại. `gap` tạo khoảng cách nhất quán và `object-fit: cover` giúp ảnh giữ tỷ lệ hiển thị đẹp. Khi xuống mobile, chỉ cần chuyển Grid thành một cột; các ảnh tiếp tục nằm trong luồng tài liệu nên không đè lên nội dung.
