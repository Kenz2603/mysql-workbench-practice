# CSS grid-row

Mở `index.html` trên trình duyệt. Nhấn 3 nút để kiểm tra `grid-row: 1 / 3`, `2 / 4` và `span 2`.

Đưa các file lên GitHub rồi chụp ảnh giao diện.
