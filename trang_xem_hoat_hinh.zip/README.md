# Phát triển trang web xem hoạt hình trực tuyến

## Nội dung đã thực hiện

- Header có logo và giữ cố định khi cuộn.
- Head-link chứa các liên kết.
- Left Content chứa danh sách video.
- Right Content chứa video chính.
- Footer chứa thông tin bản quyền.
- Bỏ gạch chân liên kết và có hiệu ứng hover.
- Sử dụng thẻ `<video>`.
- Nhúng video YouTube bằng `<iframe>`.
- Responsive cho tablet và điện thoại.

## File

- `index.html`
- `styles.css`

Lưu ý: Các video nhúng trực tuyến cần kết nối Internet để phát.
