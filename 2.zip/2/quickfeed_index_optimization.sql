-- QUICKFEED - INDEX OPTIMIZATION
-- Muc tieu: do Storage truoc/sau va loai bo 3 index du thua.

USE quickfeed_db;

-- =========================================================
-- 1. KIEM TRA CAC INDEX HIEN TAI
-- =========================================================
SHOW INDEX FROM Posts;

-- Thong ke tong quan cua bang
SHOW TABLE STATUS LIKE 'Posts';

-- Dung luong Data va Index tinh theo MB - TRUOC TOI UU
SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db'
  AND TABLE_NAME = 'Posts';

-- =========================================================
-- 2. TOI UU INDEX
-- GIU: idx_user_id, idx_created_at
-- XOA: idx_content, idx_post_type, idx_is_visible
-- =========================================================

ALTER TABLE Posts DROP INDEX idx_content;
ALTER TABLE Posts DROP INDEX idx_post_type;
ALTER TABLE Posts DROP INDEX idx_is_visible;

-- Cap nhat thong ke toi uu hoa cua bang
ANALYZE TABLE Posts;

-- =========================================================
-- 3. KIEM TRA SAU TOI UU
-- =========================================================
SHOW INDEX FROM Posts;
SHOW TABLE STATUS LIKE 'Posts';

SELECT
    TABLE_SCHEMA,
    TABLE_NAME,
    ROUND(DATA_LENGTH / 1024 / 1024, 2) AS data_mb,
    ROUND(INDEX_LENGTH / 1024 / 1024, 2) AS index_mb,
    ROUND((DATA_LENGTH + INDEX_LENGTH) / 1024 / 1024, 2) AS total_mb
FROM information_schema.TABLES
WHERE TABLE_SCHEMA = 'quickfeed_db'
  AND TABLE_NAME = 'Posts';

-- =========================================================
-- 4. KIEM TRA CAC INDEX DUOC GIU LAI
-- =========================================================

EXPLAIN
SELECT *
FROM Posts
WHERE user_id = 100;

EXPLAIN
SELECT *
FROM Posts
ORDER BY created_at DESC
LIMIT 20;

-- Ghi chu:
-- Moi INSERT truoc toi uu phai bao tri 5 secondary index
-- (ngoai PRIMARY KEY). Sau toi uu chi con 2 secondary index.
-- Nhu vay moi INSERT giam 3 lan bao tri/cap nhat secondary B-Tree.
--
-- Neu can tim kiem tu khoa trong content, can can nhac FULLTEXT:
-- CREATE FULLTEXT INDEX idx_content_fulltext ON Posts(content);
-- SELECT * FROM Posts
-- WHERE MATCH(content) AGAINST('keyword' IN NATURAL LANGUAGE MODE);
