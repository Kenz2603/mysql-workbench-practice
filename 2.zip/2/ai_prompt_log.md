# AI Prompt Log – QuickFeed

## Prompt 1 – TEXT và BOOLEAN index
**Prompt:** Trong MySQL, nếu tạo B-Tree index trên một cột TEXT dài và một cột BOOLEAN chỉ có 0/1, điều này ảnh hưởng thế nào đến RAM, Disk và Query Optimizer?

**Tóm tắt kết quả:** Index trên TEXT prefix có key lớn, tăng kích thước secondary index và chi phí bảo trì. BOOLEAN có cardinality rất thấp nên thường không chọn lọc đủ để index mang lại lợi ích cho truy vấn trả về phần lớn bảng.

## Prompt 2 – Cardinality
**Prompt:** Cardinality của index là gì và tại sao cột `is_visible` với 99% giá trị bằng 1 thường là ứng viên kém cho B-Tree index?

**Tóm tắt kết quả:** Cardinality thể hiện mức độ phân biệt của giá trị index. Khi điều kiện lọc khớp phần lớn số dòng, optimizer có thể chọn full table scan vì dùng index vẫn phải truy cập quá nhiều bản ghi.

## Prompt 3 – Storage
**Prompt:** Hãy cho truy vấn `information_schema.TABLES` để xem `DATA_LENGTH` và `INDEX_LENGTH` của bảng Posts theo MB.

**Tóm tắt kết quả:** Có thể chia `DATA_LENGTH` và `INDEX_LENGTH` cho `1024 * 1024`, dùng `ROUND()` để hiển thị MB và lọc theo `TABLE_SCHEMA`, `TABLE_NAME`.

## Prompt 4 – InnoDB
**Prompt:** InnoDB quản lý Data Pages và secondary Index Pages như thế nào, và tại sao nhiều secondary index làm INSERT tốn I/O hơn?

**Tóm tắt kết quả:** InnoDB lưu clustered index và các secondary index trong các B+Tree riêng. Khi INSERT, các index liên quan đều phải được cập nhật; nhiều index làm tăng page access, ghi log và có thể gây page split.

## Prompt 5 – FULLTEXT
**Prompt:** Nếu cần tìm kiếm từ khóa trong cột `content` kiểu TEXT, nên dùng cơ chế nào của MySQL thay cho B-Tree prefix index?

**Tóm tắt kết quả:** Có thể sử dụng `FULLTEXT INDEX` cùng `MATCH(...) AGAINST(...)` cho nhu cầu tìm kiếm văn bản phù hợp.
