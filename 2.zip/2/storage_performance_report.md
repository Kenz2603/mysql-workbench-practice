# Storage & Performance Report – QuickFeed

## Chẩn đoán

Bảng `Posts` bị over-indexing vì ngoài `PRIMARY KEY`, mỗi lần `INSERT` còn phải duy trì 5 secondary index. Việc thêm một bản ghi không chỉ ghi dữ liệu mà còn phải chèn khóa vào các cấu trúc B-Tree tương ứng. Điều này làm tăng I/O, sử dụng buffer pool, phát sinh thêm page split khi cần và làm tăng dung lượng lưu trữ.

Ba index cần loại bỏ là `idx_content`, `idx_post_type` và `idx_is_visible`. `idx_content` lập chỉ mục prefix 255 ký tự của cột `TEXT`, nên có khóa tương đối lớn và tốn storage. `post_type` chỉ có ba giá trị, còn `is_visible` chỉ có hai giá trị nên có cardinality thấp. Đặc biệt, nếu 99% bản ghi có `is_visible = 1`, truy vấn giá trị này trả về phần lớn bảng; optimizer có thể thấy full table scan rẻ hơn việc đọc index rồi truy cập rất nhiều bản ghi.

Giữ `idx_user_id` vì phù hợp truy vấn bài viết theo người dùng và giữ `idx_created_at` cho các truy vấn theo thời gian.

## So sánh Storage

Điền số liệu thực tế sau khi chạy script:

| Thời điểm | Data MB | Index MB | Total MB |
|---|---:|---:|---:|
| Trước tối ưu | ____ | ____ | ____ |
| Sau tối ưu | ____ | ____ | ____ |
| Chênh lệch Index | - | ____ MB | - |

## Kết luận

Sau tối ưu, mỗi `INSERT` không còn phải duy trì ba secondary B-Tree đã xóa. Đây là sự đánh đổi giữa Read và Write: index phù hợp có thể tăng tốc truy vấn đọc, nhưng mỗi index bổ sung tiêu tốn disk/RAM và làm tăng chi phí ghi. Với tìm kiếm nội dung văn bản, nên đánh giá `FULLTEXT` thay vì B-Tree prefix index thông thường.

> Lưu ý: số MB phải lấy từ môi trường MySQL thực tế; không nên tự tạo số liệu. Với bảng mẫu rất nhỏ, thay đổi `Index_length` có thể chưa thể hiện rõ ngay do cách InnoDB cấp phát và báo cáo thống kê.
