# Bài thực hành: Tạo trang đọc truyện ngắn

## File
- `index.html`: nội dung trang đọc truyện.
- `styles.css`: CSS được nhúng bằng thẻ `<link>`.

## Nội dung đã thực hiện
- Ảnh truyện ở đầu trang.
- Mục lục sử dụng thẻ `h5`.
- Liên kết từ mục lục đến từng truyện bằng anchor.
- External CSS.
- Định dạng font, cỡ chữ, màu sắc và căn giữa tiêu đề.
- Khối mục lục có border, background-color và padding.
- Hiệu ứng hover cho liên kết.
- Nội dung truyện sử dụng line-height, text-align và text-indent.
