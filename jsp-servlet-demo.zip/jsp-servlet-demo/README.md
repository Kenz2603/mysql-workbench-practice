# jsp-servlet-demo

Bài thực hành: Tạo trang web hiển thị thời gian hệ thống.

## Công nghệ
- Java 17
- Maven
- Jakarta Servlet API 6.0
- JSP API 3.1
- Tomcat 10.1+

## Build
```bash
mvn clean package
```

Sau khi BUILD SUCCESS, file WAR nằm tại:
`target/jsp-servlet-demo.war`

## URL sau khi deploy
- Trang JSP: `http://localhost:8080/jsp-servlet-demo/`
- Servlet: `http://localhost:8080/jsp-servlet-demo/hello`
