# jsp-servlet-dictionary

Ứng dụng từ điển Anh - Việt đơn giản bằng JSP/Servlet.

## Từ có sẵn
- hello → Xin chào
- how → Thế nào
- book → Quyển sách
- computer → Máy tính
- student → Sinh viên

## Công nghệ
Java 17, Maven, Jakarta Servlet 6.0, JSP 3.1.1, Tomcat 10.1+.

## Build
```bash
mvn clean package
```

WAR: `target/jsp-servlet-dictionary.war`

URL sau khi deploy:
`http://localhost:8080/jsp-servlet-dictionary/`
