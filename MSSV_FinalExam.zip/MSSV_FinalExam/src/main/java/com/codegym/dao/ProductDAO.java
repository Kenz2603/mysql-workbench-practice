package com.codegym.dao;
import com.codegym.model.Product;
import java.sql.*;
import java.util.*;
import java.math.BigDecimal;

public class ProductDAO implements IProductDAO {
    private static final String URL="jdbc:mysql://localhost:3306/product_management?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER="root";
    private static final String PASSWORD="password"; // Đổi theo MySQL của bạn

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public List<Product> findAll() throws SQLException {
        List<Product> list=new ArrayList<>();
        try(Connection c=getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM products ORDER BY id"); ResultSet rs=ps.executeQuery()){
            while(rs.next()) list.add(map(rs));
        }
        return list;
    }
    public Product findById(int id) throws SQLException {
        try(Connection c=getConnection(); PreparedStatement ps=c.prepareStatement("SELECT * FROM products WHERE id=?")){
            ps.setInt(1,id);
            try(ResultSet rs=ps.executeQuery()){ return rs.next()?map(rs):null; }
        }
    }
    public void insert(Product p) throws SQLException {
        try(Connection c=getConnection(); PreparedStatement ps=c.prepareStatement("INSERT INTO products(name,price,quantity) VALUES(?,?,?)")){
            ps.setString(1,p.getName()); ps.setBigDecimal(2,p.getPrice()); ps.setInt(3,p.getQuantity()); ps.executeUpdate();
        }
    }
    public boolean update(Product p) throws SQLException {
        try(Connection c=getConnection(); PreparedStatement ps=c.prepareStatement("UPDATE products SET name=?,price=?,quantity=? WHERE id=?")){
            ps.setString(1,p.getName()); ps.setBigDecimal(2,p.getPrice()); ps.setInt(3,p.getQuantity()); ps.setInt(4,p.getId());
            return ps.executeUpdate()>0;
        }
    }
    public boolean delete(int id) throws SQLException {
        try(Connection c=getConnection(); PreparedStatement ps=c.prepareStatement("DELETE FROM products WHERE id=?")){
            ps.setInt(1,id); return ps.executeUpdate()>0;
        }
    }
    private Product map(ResultSet rs) throws SQLException {
        return new Product(rs.getInt("id"),rs.getString("name"),rs.getBigDecimal("price"),rs.getInt("quantity"));
    }
}
