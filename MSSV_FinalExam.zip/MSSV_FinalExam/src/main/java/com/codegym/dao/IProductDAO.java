package com.codegym.dao;
import com.codegym.model.Product;
import java.sql.SQLException;
import java.util.List;

public interface IProductDAO {
    List<Product> findAll() throws SQLException;
    Product findById(int id) throws SQLException;
    void insert(Product product) throws SQLException;
    boolean update(Product product) throws SQLException;
    boolean delete(int id) throws SQLException;
}
