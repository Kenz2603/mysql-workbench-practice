package com.codegym.controller;
import com.codegym.dao.*;
import com.codegym.model.Product;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.SQLException;

@WebServlet("/products")
public class ProductServlet extends HttpServlet {
    private IProductDAO dao;
    public void init(){ dao=new ProductDAO(); }

    protected void doGet(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException {
        String action=req.getParameter("action"); if(action==null) action="list";
        try {
            switch(action){
                case "create" -> req.getRequestDispatcher("/product/create.jsp").forward(req,resp);
                case "edit" -> { req.setAttribute("product",dao.findById(Integer.parseInt(req.getParameter("id")))); req.getRequestDispatcher("/product/edit.jsp").forward(req,resp); }
                case "delete" -> { dao.delete(Integer.parseInt(req.getParameter("id"))); resp.sendRedirect("products"); }
                default -> { req.setAttribute("products",dao.findAll()); req.getRequestDispatcher("/product/list.jsp").forward(req,resp); }
            }
        } catch(SQLException e){ throw new ServletException(e); }
    }

    protected void doPost(HttpServletRequest req,HttpServletResponse resp) throws ServletException,IOException {
        req.setCharacterEncoding("UTF-8");
        String action=req.getParameter("action");
        try {
            String name=req.getParameter("name");
            BigDecimal price=new BigDecimal(req.getParameter("price"));
            int quantity=Integer.parseInt(req.getParameter("quantity"));
            if("edit".equals(action)) dao.update(new Product(Integer.parseInt(req.getParameter("id")),name,price,quantity));
            else dao.insert(new Product(name,price,quantity));
            resp.sendRedirect("products");
        } catch(SQLException e){ throw new ServletException(e); }
    }
}
