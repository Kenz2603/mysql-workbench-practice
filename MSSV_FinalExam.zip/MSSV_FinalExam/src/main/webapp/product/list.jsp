<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Quản lý sản phẩm</title>
<style>body{font-family:Arial;max-width:950px;margin:35px auto;background:#f5f6fa}.box{background:white;padding:24px;border-radius:10px}table{width:100%;border-collapse:collapse}th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left}.btn{display:inline-block;padding:9px 14px;background:#2563eb;color:#fff;text-decoration:none;border-radius:6px}.danger{color:#dc2626}</style>
</head><body><div class="box"><h1>Quản lý sản phẩm</h1><p><a class="btn" href="products?action=create">+ Thêm sản phẩm</a></p>
<table><tr><th>ID</th><th>Tên sản phẩm</th><th>Giá</th><th>Số lượng</th><th>Thao tác</th></tr>
<c:forEach items="${products}" var="p"><tr><td>${p.id}</td><td><c:out value="${p.name}"/></td><td>${p.price}</td><td>${p.quantity}</td>
<td><a href="products?action=edit&id=${p.id}">Sửa</a> | <a class="danger" href="products?action=delete&id=${p.id}" onclick="return confirm('Bạn chắc chắn muốn xóa sản phẩm này?')">Xóa</a></td></tr></c:forEach>
</table></div></body></html>