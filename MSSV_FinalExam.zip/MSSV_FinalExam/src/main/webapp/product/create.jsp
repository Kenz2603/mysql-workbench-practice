<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Thêm sản phẩm</title>
<style>body{font-family:Arial;max-width:650px;margin:40px auto}label{display:block;margin-top:15px}input{width:100%;padding:10px;box-sizing:border-box}button{margin-top:20px;padding:10px 18px}</style></head>
<body><h2>Thêm sản phẩm</h2><form method="post" action="products"><input type="hidden" name="action" value="create">
<label>Tên sản phẩm</label><input name="name" required><label>Giá</label><input name="price" type="number" min="0" step="0.01" required>
<label>Số lượng</label><input name="quantity" type="number" min="0" required><button type="submit">Lưu</button> <a href="products">Hủy</a>
</form></body></html>