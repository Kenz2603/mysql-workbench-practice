<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Sửa sản phẩm</title>
<style>body{font-family:Arial;max-width:650px;margin:40px auto}label{display:block;margin-top:15px}input{width:100%;padding:10px;box-sizing:border-box}button{margin-top:20px;padding:10px 18px}</style></head>
<body><h2>Sửa sản phẩm</h2><form method="post" action="products"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="${product.id}">
<label>Tên sản phẩm</label><input name="name" value="<c:out value='${product.name}'/>" required>
<label>Giá</label><input name="price" type="number" min="0" step="0.01" value="${product.price}" required>
<label>Số lượng</label><input name="quantity" type="number" min="0" value="${product.quantity}" required>
<button type="submit">Cập nhật</button> <a href="products">Hủy</a></form></body></html>