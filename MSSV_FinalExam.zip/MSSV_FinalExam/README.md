# Final Exam - Product Management

Ứng dụng Java Web JSP/Servlet/JDBC/MySQL đáp ứng yêu cầu:
- Hiển thị danh sách sản phẩm
- Thêm sản phẩm
- Sửa sản phẩm
- Xóa sản phẩm có xác nhận
- MySQL bảng `products(id, name, price, quantity)`

## Chạy dự án
1. Chạy `database.sql` trong MySQL.
2. Sửa `PASSWORD` trong `ProductDAO.java` cho đúng máy.
3. Chạy `mvn clean package`.
4. Copy `target/product-management.war` vào `webapps` của Tomcat 10.1+.
5. Mở `http://localhost:8080/product-management/products`.

## Nộp bài
Đổi tên file ZIP từ `MSSV_FinalExam.zip` thành `[Mã_số_sinh_viên]_FinalExam.zip`.
