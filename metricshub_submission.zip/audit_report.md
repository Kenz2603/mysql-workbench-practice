# Audit Legacy MetricsHub

- **Navbar:** Grid với cột pixel cố định không phù hợp nội dung động. Chuỗi dài có thể tràn. Giải pháp: Flexbox + `flex-wrap`.
- **Dashboard:** Flexbox lồng nhiều `.column` làm DOM sâu và khó mô tả widget span cả hàng lẫn cột. Giải pháp: một `.grid-dashboard`, các widget là siblings và dùng CSS Grid.
- **Pricing:** Float + media query thủ công lặp lại chức năng framework đã có. Giải pháp: Bootstrap `row`, `col-12 col-md-4`, `card`.
