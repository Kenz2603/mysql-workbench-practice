# AI Prompt Log

## 1. Phân tích Bento Dashboard
**Prompt:** Khi một widget cần chiếm 2 hàng và 2 cột, nên chọn CSS Grid hay Flexbox? Vì sao?

**Kết luận:** Chọn CSS Grid vì Grid điều khiển đồng thời hai chiều và hỗ trợ `grid-row` / `grid-column: span ...`; Flexbox chủ yếu xử lý một trục nên thường cần thêm wrapper.

## 2. Bootstrap Grid
**Prompt:** `col-sm-4` và `col-md-4` khác nhau thế nào trong Bootstrap 5?

**Kết luận:** Chúng bắt đầu áp dụng từ các breakpoint khác nhau. Với bài này dùng `col-12 col-md-4`: mobile chiếm 12/12 cột, từ `md` trở lên mỗi card chiếm 4/12.

## 3. Thuộc tính gap
**Prompt:** Có thể dùng `gap` cho cả Grid và Flexbox để thay thế nhiều margin thủ công không?

**Kết luận:** Có. `gap` tạo khoảng cách nhất quán giữa các phần tử mà không cần xử lý margin ở phần tử đầu/cuối.

## 4. Navbar responsive
**Prompt:** Làm sao để Navbar Flexbox không tràn khi nội dung dài?

**Kết luận:** Dùng `flex-wrap: wrap`, `gap` và tránh chiều rộng pixel cố định; ở mobile có thể đổi hướng thành cột.

## 5. Responsive Test
**Prompt:** Dashboard 3 cột nên thay đổi thế nào trên tablet và mobile?

**Kết luận:** Tablet giảm còn 2 cột; mobile về 1 cột và bỏ span đặc biệt để tránh widget tràn.
