# Bài thực hành: Tạo menu ngang

Bài gồm:
- `index.html`
- `styles.css`

Menu chính hiển thị theo hàng ngang bằng `float: left`.
Sem 1 và Sem 2 có menu con dạng dropdown.
Khi hover, liên kết đổi nền sang màu đỏ và menu con được hiển thị.
