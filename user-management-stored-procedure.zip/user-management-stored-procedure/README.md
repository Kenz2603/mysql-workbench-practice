# Gọi MySQL Stored Procedures từ JDBC

Bài thực hành cập nhật ứng dụng `user-management` để dùng `CallableStatement` và MySQL Stored Procedures cho:

- Tìm User theo ID: `get_user_by_id`.
- Thêm User mới: `insert_user`.

## Chạy bài

1. Chạy `database.sql` trong MySQL Workbench để tạo database, bảng và 2 stored procedures.
2. Mở `UserDAO.java` và đổi `jdbcPassword` cho đúng mật khẩu MySQL trên máy.
3. Build dự án:

```bash
mvn clean package
```

4. Deploy file WAR trong `target/` lên Tomcat 10.1+.
5. Truy cập: `http://localhost:8080/user-management/users`.

Các chức năng tìm kiếm theo country và sắp xếp theo name của bài trước vẫn được giữ nguyên. Form Edit dùng `getUserById()` và chức năng Create dùng `insertUserStore()`.
