package com.codegym.dao;
import com.codegym.model.User;
import java.sql.*; import java.util.*;
public class UserDAO implements IUserDAO {
 private final String jdbcURL="jdbc:mysql://localhost:3306/demo?useSSL=false";
 private final String jdbcUsername="root";
 private final String jdbcPassword="password";
 private static final String INSERT="INSERT INTO users(name,email,country) VALUES(?,?,?)";
 private static final String ONE="SELECT id,name,email,country FROM users WHERE id=?";
 private static final String ALL="SELECT * FROM users";
 private static final String DELETE="DELETE FROM users WHERE id=?";
 private static final String UPDATE="UPDATE users SET name=?,email=?,country=? WHERE id=?";
 private static final String SEARCH_COUNTRY="SELECT * FROM users WHERE country LIKE ?";
 private static final String SORT_NAME="SELECT * FROM users ORDER BY name ASC";
 protected Connection getConnection() {
  try { Class.forName("com.mysql.cj.jdbc.Driver"); return DriverManager.getConnection(jdbcURL,jdbcUsername,jdbcPassword); }
  catch(Exception e){ throw new RuntimeException(e); }
 }
 public void insertUser(User u)throws SQLException{
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(INSERT)){p.setString(1,u.getName());p.setString(2,u.getEmail());p.setString(3,u.getCountry());p.executeUpdate();}
 }
 public User selectUser(int id){
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(ONE)){p.setInt(1,id);try(ResultSet r=p.executeQuery()){if(r.next())return new User(id,r.getString("name"),r.getString("email"),r.getString("country"));}}
  catch(SQLException e){throw new RuntimeException(e);} return null;
 }
 public List<User> selectAllUsers(){
  List<User> list=new ArrayList<>();
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(ALL);ResultSet r=p.executeQuery()){
   while(r.next())list.add(new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("country")));
  }catch(SQLException e){throw new RuntimeException(e);} return list;
 }
 public boolean deleteUser(int id)throws SQLException{try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(DELETE)){p.setInt(1,id);return p.executeUpdate()>0;}}
 public boolean updateUser(User u)throws SQLException{try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(UPDATE)){p.setString(1,u.getName());p.setString(2,u.getEmail());p.setString(3,u.getCountry());p.setInt(4,u.getId());return p.executeUpdate()>0;}}

 public List<User> searchByCountry(String country){
  List<User> list=new ArrayList<>();
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(SEARCH_COUNTRY)){
   p.setString(1,"%"+country+"%");
   try(ResultSet r=p.executeQuery()){
    while(r.next()) list.add(new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("country")));
   }
  }catch(SQLException e){throw new RuntimeException(e);}
  return list;
 }
 public List<User> sortByName(){
  List<User> list=new ArrayList<>();
  try(Connection c=getConnection();PreparedStatement p=c.prepareStatement(SORT_NAME);ResultSet r=p.executeQuery()){
   while(r.next()) list.add(new User(r.getInt("id"),r.getString("name"),r.getString("email"),r.getString("country")));
  }catch(SQLException e){throw new RuntimeException(e);}
  return list;
 }
 public User getUserById(int id){
  User user=null;
  String query="{CALL get_user_by_id(?)}";
  try(Connection c=getConnection();CallableStatement cs=c.prepareCall(query)){
   cs.setInt(1,id);
   try(ResultSet r=cs.executeQuery()){
    if(r.next()) user=new User(id,r.getString("name"),r.getString("email"),r.getString("country"));
   }
  }catch(SQLException e){throw new RuntimeException(e);}
  return user;
 }
 public void insertUserStore(User u)throws SQLException{
  String query="{CALL insert_user(?, ?, ?)}";
  try(Connection c=getConnection();CallableStatement cs=c.prepareCall(query)){
   cs.setString(1,u.getName());
   cs.setString(2,u.getEmail());
   cs.setString(3,u.getCountry());
   cs.executeUpdate();
  }
 }
}
