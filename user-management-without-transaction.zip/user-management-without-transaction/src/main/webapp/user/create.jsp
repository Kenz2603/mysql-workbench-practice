<%@ page contentType="text/html;charset=UTF-8" %><!DOCTYPE html><html><body><h2>Thêm Mới User</h2>
<form action="${pageContext.request.contextPath}/users?action=create" method="post">
Tên: <input name="name" required><br>Email: <input type="email" name="email" required><br>Quốc gia: <input name="country" required><br>
<div class="form-group">
<label>Quyền hạn (Permissions):</label>
<div style="display:flex;gap:15px;margin-top:5px;">
<label><input type="checkbox" name="permissions" value="1"> Thêm (Add)</label>
<label><input type="checkbox" name="permissions" value="2"> Sửa (Edit)</label>
<label><input type="checkbox" name="permissions" value="3"> Xoá (Delete)</label>
<label><input type="checkbox" name="permissions" value="4"> Xem (View)</label>
</div></div>
<button>Lưu</button>
</form><a href="${pageContext.request.contextPath}/users">Quay lại</a></body></html>