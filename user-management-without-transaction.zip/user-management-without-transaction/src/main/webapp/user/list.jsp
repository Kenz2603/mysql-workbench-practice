<%@ taglib prefix="c" uri="jakarta.tags.core" %><%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><body><h2>Danh Sách Người Dùng</h2>
<a href="${pageContext.request.contextPath}/users?action=create">Thêm mới User</a>
<form action="${pageContext.request.contextPath}/users" method="get" style="margin:15px 0">
<input type="hidden" name="action" value="search">
<input type="text" name="country" placeholder="Nhập country">
<button type="submit">Tìm kiếm</button>
<a href="${pageContext.request.contextPath}/users?action=sort">Sắp xếp theo name</a>
<a href="${pageContext.request.contextPath}/users">Tất cả</a>
</form>
<table border="1" cellpadding="8"><tr><th>ID</th><th>Tên</th><th>Email</th><th>Quốc gia</th><th>Hành động</th></tr>
<c:forEach var="user" items="${requestScope.listUser}"><tr><td>${user.id}</td><td><c:out value="${user.name}"/></td><td><c:out value="${user.email}"/></td><td><c:out value="${user.country}"/></td>
<td><a href="${pageContext.request.contextPath}/users?action=edit&id=${user.id}">Sửa</a> <a href="${pageContext.request.contextPath}/users?action=delete&id=${user.id}">Xóa</a></td></tr></c:forEach>
</table></body></html>