<%@ page contentType="text/html;charset=UTF-8" %><!DOCTYPE html><html><body><h2>Xác Nhận Xóa User</h2>
<p>Tên: ${user.name}</p><p>Email: ${user.email}</p><p>Quốc gia: ${user.country}</p>
<form action="${pageContext.request.contextPath}/users?action=delete" method="post"><input type="hidden" name="id" value="${user.id}"><button>Đồng ý Xóa</button></form>
<a href="${pageContext.request.contextPath}/users">Hủy</a></body></html>