# Thực thi SQL không sử dụng Transaction

Bài thực hành minh họa hiện tượng dữ liệu được ghi một phần khi JDBC chạy với auto-commit mặc định.

## Chạy
1. Đổi `jdbcPassword` trong `UserDAO.java` theo MySQL của máy.
2. Chạy `database.sql`.
3. Chạy `mvn clean package` và deploy WAR lên Tomcat 10.1+.
4. Truy cập: `http://localhost:8080/user-management/users?action=test-without-tran`.
5. Kiểm tra: `SELECT * FROM Employee;`.

Kết quả mong đợi: Quynh và Ngan đã được INSERT, còn UPDATE cố tình lỗi. Do không dùng transaction và auto-commit mặc định bật, hai bản ghi INSERT vẫn tồn tại.
