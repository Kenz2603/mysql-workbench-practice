# Giao diện giản lược của trang chủ Facebook

## Yêu cầu đã thực hiện
- Fixed header ở trên cùng bằng `position: fixed`.
- Sidebar bên trái.
- Sidebar danh sách người liên hệ bên phải.
- Khu vực nội dung chính ở giữa.
- Khung tạo bài viết.
- Các bài viết mẫu.
- Hiệu ứng hover.
- Responsive khi màn hình nhỏ.

## File
- `index.html`
- `styles.css`

Đây là giao diện thực hành HTML/CSS, không phải trang Facebook thật.
