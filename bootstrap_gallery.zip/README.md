# Tạo gallery đơn giản sử dụng Bootstrap

Bài sử dụng Bootstrap Grid System:

- `col-12`: Mobile - 1 ảnh / dòng.
- `col-sm-6`: Tablet - 2 ảnh / dòng.
- `col-lg-3`: Desktop - 4 ảnh / dòng.
- `container`, `row`, `g-4` để tổ chức bố cục responsive.

Mở `index.html` bằng trình duyệt hoặc Live Server để kiểm tra.
