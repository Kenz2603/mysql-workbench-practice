# User Management
Java 17 + Maven + JSP/Servlet + JDBC + MySQL + Tomcat 10.1+.

1. Chạy `database.sql`.
2. Sửa `jdbcUsername` và `jdbcPassword` trong `UserDAO.java`.
3. Chạy `mvn clean package`.
4. Deploy `target/user-management.war`.
5. Mở `http://localhost:8080/user-management/users`.
