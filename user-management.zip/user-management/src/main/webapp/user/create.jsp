<%@ page contentType="text/html;charset=UTF-8" %><!DOCTYPE html><html><body><h2>Thêm Mới User</h2>
<form action="${pageContext.request.contextPath}/users?action=create" method="post">
Tên: <input name="name" required><br>Email: <input type="email" name="email" required><br>Quốc gia: <input name="country" required><br><button>Lưu</button>
</form><a href="${pageContext.request.contextPath}/users">Quay lại</a></body></html>