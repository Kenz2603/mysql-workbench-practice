# Thực thi SQL có sử dụng Transaction

Bài thực hành tiếp nối ứng dụng `user-management`.

## Nội dung đã bổ sung
- `IUserDAO.insertUpdateUseTransaction()`
- `UserDAO.insertUpdateUseTransaction()` với `setAutoCommit(false)`, `commit()` và `rollback()`
- Route: `users?action=test-use-tran`
- Giữ lại bài `test-without-tran` để có thể so sánh.

## Chạy bài
1. Sửa `jdbcPassword` trong `UserDAO.java` cho đúng MySQL trên máy.
2. Chạy `database.sql` nếu database `demo` chưa được chuẩn bị.
3. Build: `mvn clean package`
4. Deploy WAR lên Tomcat 10.1+.
5. Mở: `http://localhost:8080/user-management/users?action=test-use-tran`
6. Kiểm tra: `SELECT * FROM Employee;`

### Lần 1 - kiểm tra rollback
Code cố tình gán sai parameter của `psUpdate`, nên UPDATE phát sinh lỗi. Phương thức bắt lỗi và gọi `rollback()` rõ ràng; hai INSERT trong transaction không được giữ lại.

### Lần 2 - kiểm tra commit
Trong `UserDAO.java`, comment:
`psUpdate.setBigDecimal(2, new BigDecimal("999.99"));`

và mở comment:
`psUpdate.setBigDecimal(1, new BigDecimal("999.99"));`

Build/deploy lại. Kết quả mong đợi: có Quynh và Ngan; salary của Quynh là `999.99`.

> Ghi chú: phần DROP/CREATE bảng được thực hiện trước khi tắt auto-commit. Phần INSERT/UPDATE mới nằm trong transaction cần kiểm nghiệm.
