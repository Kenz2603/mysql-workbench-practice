package com.codegym.calculator;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(name="CalculatorServlet", urlPatterns="/calculate")
public class CalculatorServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        try {
            double first = Double.parseDouble(request.getParameter("firstOperand"));
            double second = Double.parseDouble(request.getParameter("secondOperand"));
            char operator = request.getParameter("operator").charAt(0);
            double result = Calculator.calculate(first, second, operator);
            request.setAttribute("first", first);
            request.setAttribute("second", second);
            request.setAttribute("operator", operator);
            request.setAttribute("result", result);
        } catch (Exception e) {
            request.setAttribute("error", e.getMessage());
        }
        request.getRequestDispatcher("/result.jsp").forward(request, response);
    }
}
