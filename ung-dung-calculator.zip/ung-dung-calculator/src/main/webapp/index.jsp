<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Calculator</title>
<style>body{font-family:Arial;margin:50px}.box{width:360px;padding:25px;border:1px solid #ccc}input,select,button{padding:9px;margin:7px 0;width:100%;box-sizing:border-box}button{cursor:pointer}</style>
</head><body><div class="box"><h2>Simple Calculator</h2>
<form action="calculate" method="post">
<label>First operand:</label><input type="number" step="any" name="firstOperand" required>
<label>Operator:</label><select name="operator"><option value="+">Addition (+)</option><option value="-">Subtraction (-)</option><option value="*">Multiplication (*)</option><option value="/">Division (/)</option></select>
<label>Second operand:</label><input type="number" step="any" name="secondOperand" required>
<button type="submit">Calculate</button>
</form></div></body></html>