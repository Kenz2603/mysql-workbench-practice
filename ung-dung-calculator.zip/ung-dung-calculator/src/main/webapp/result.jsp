<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Calculator Result</title>
<style>body{font-family:Arial;margin:50px}.box{width:420px;padding:25px;border:1px solid #ccc}.error{color:#c00}.result{color:#087a20}a{display:inline-block;margin-top:15px}</style>
</head><body><div class="box"><h2>Calculator Result</h2>
<% if(request.getAttribute("error") != null) { %>
<p class="error">Error: <%= request.getAttribute("error") %></p>
<% } else { %>
<p>First operand: <b><%= request.getAttribute("first") %></b></p>
<p>Operator: <b><%= request.getAttribute("operator") %></b></p>
<p>Second operand: <b><%= request.getAttribute("second") %></b></p>
<p class="result">Result: <b><%= request.getAttribute("result") %></b></p>
<% } %><a href="index.jsp">Quay lại</a></div></body></html>