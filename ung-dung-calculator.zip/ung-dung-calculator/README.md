# Ứng dụng Calculator

Ứng dụng Java Web dùng Servlet + JSP với 4 phép toán: cộng, trừ, nhân, chia.

- `Calculator.calculate()` thực hiện phép tính và ném Exception khi chia cho 0.
- `CalculatorServlet` nhận dữ liệu POST, dùng try/catch và forward sang `result.jsp`.
- Java 17, Maven, Jakarta Servlet 6, Tomcat 10.1+.

## Build
`mvn clean package`

Deploy `target/servlet-jsp-calculator.war`, truy cập:
`http://localhost:8080/servlet-jsp-calculator/`
