# Sử dụng Bootstrap xây dựng form login

Bài thực hành gồm:
- `index.html`
- `styles.css`
- `bootstrap.png`

Bootstrap 5 được nhúng bằng CDN theo hướng dẫn của bài.
Mở `index.html` bằng trình duyệt để xem form đăng nhập.
