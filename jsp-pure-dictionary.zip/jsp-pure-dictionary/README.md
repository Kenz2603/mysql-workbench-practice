# Ứng dụng Từ điển đơn giản - JSP

Dự án Maven Webapp dùng JSP, tương thích Tomcat 10.1+.

## Chức năng
- Nhập từ tiếng Anh tại `index.jsp`.
- Gửi POST đến `dictionary.jsp`.
- Tra cứu bằng `Map<String, String>` trong JSP Scriptlet.
- Hiển thị nghĩa bằng JSP Expression hoặc thông báo không tìm thấy.

## Chạy
```bash
mvn clean package
```

File WAR: `target/jsp-pure-dictionary.war`

Deploy WAR lên Tomcat 10.1+, sau đó truy cập:
`http://localhost:8080/jsp-pure-dictionary/`
