# Bài thực hành: Tạo layout với RWD

Trang được xây dựng bằng DIV và CSS, gồm:

- Header / menu
- Sidebar trái
- Nội dung chính
- Sidebar phải chứa ADS
- Footer

Responsive Web Design được thực hiện bằng `@media`:
- Desktop: bố cục 3 cột.
- Tablet: sidebar phải chuyển xuống dưới.
- Mobile: các khu vực chuyển thành bố cục một cột.

Mở `index.html` và thay đổi kích thước cửa sổ trình duyệt để kiểm tra responsive.
