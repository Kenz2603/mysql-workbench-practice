# JOIN Analysis

Trong báo cáo Marketing phải dùng `COUNT(o.order_id)` thay vì `COUNT(*)`. Khi dùng `LEFT JOIN`, khách hàng chưa có đơn hàng vẫn được giữ lại và phía bảng `Orders` sẽ chứa các giá trị `NULL`. `COUNT(*)` đếm số dòng kết quả sau JOIN nên Charlie vẫn tạo ra một dòng và có thể bị đếm thành 1, gây sai số. Ngược lại, `COUNT(o.order_id)` chỉ đếm các giá trị `order_id` khác `NULL`, nên khách hàng chưa từng mua hàng sẽ có `total_orders = 0`. Đây là cách phù hợp để vừa giữ đầy đủ dữ liệu từ bảng `Customers`, vừa đếm chính xác số giao dịch thực tế.
