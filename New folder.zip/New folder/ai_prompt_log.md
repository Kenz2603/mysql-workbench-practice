# AI Prompt Log – FlashMart

## Prompt 1 – INNER JOIN và LEFT JOIN
**Prompt:**  
Trong MySQL, nếu chỉ viết `JOIN` mà không ghi `LEFT` hay `RIGHT` thì nó hoạt động như thế nào? Các bản ghi không có dữ liệu khớp ở hai bảng có bị loại bỏ không?

**Kết luận áp dụng:**  
`JOIN` mặc định là `INNER JOIN`, chỉ giữ các dòng có dữ liệu khớp ở cả hai bảng. Vì vậy Charlie bị loại khỏi báo cáo cũ.

## Prompt 2 – COUNT(*) và COUNT(cột)
**Prompt:**  
Khi dùng `LEFT JOIN`, sự khác nhau giữa `COUNT(*)` và `COUNT(o.order_id)` là gì nếu bảng bên phải không có bản ghi khớp?

**Kết luận áp dụng:**  
`COUNT(*)` đếm cả dòng được giữ lại bởi `LEFT JOIN`, còn `COUNT(o.order_id)` bỏ qua `NULL`. Vì vậy dùng `COUNT(o.order_id)` để Charlie có kết quả 0.

## Prompt 3 – Anti-Join
**Prompt:**  
Tại sao `LEFT JOIN ... WHERE o.order_id IS NULL` có thể dùng để tìm các sản phẩm chưa từng xuất hiện trong bảng `Orders`?

**Kết luận áp dụng:**  
`LEFT JOIN` giữ toàn bộ sản phẩm. Những sản phẩm không có đơn hàng sẽ có cột từ `Orders` là `NULL`, nên có thể lọc bằng `WHERE o.order_id IS NULL`.

## Prompt 4 – LEFT JOIN ... IS NULL và NOT IN
**Prompt:**  
So sánh `LEFT JOIN ... IS NULL` với `NOT IN` khi cần tìm bản ghi không tồn tại trong bảng khác. Có rủi ro nào liên quan đến `NULL` không?

**Kết luận áp dụng:**  
`NOT IN` có thể cho kết quả khó dự đoán khi tập con chứa `NULL`. Anti-Join bằng `LEFT JOIN ... IS NULL` thường rõ ràng hơn về mặt logic.

## Prompt 5 – Nested-Loop Join
**Prompt:**  
MySQL Optimizer thường thực thi JOIN bằng Nested-Loop Join như thế nào và index trên các cột JOIN có tác dụng gì?

**Kết luận áp dụng:**  
MySQL duyệt các dòng của bảng dẫn và tìm bản ghi khớp ở bảng còn lại. Index trên `customer_id` hoặc `product_id` giúp giảm chi phí tìm kiếm khi JOIN trên dữ liệu lớn.

## Prompt 6 – FULL OUTER JOIN trong MySQL
**Prompt:**  
MySQL không hỗ trợ trực tiếp `FULL OUTER JOIN`; có thể mô phỏng bằng cách kết hợp `LEFT JOIN` và `RIGHT JOIN` với `UNION` không?

**Kết luận áp dụng:**  
Có thể dùng `LEFT JOIN ... UNION ... RIGHT JOIN` để mô phỏng FULL OUTER JOIN khi cần giữ dữ liệu từ cả hai phía.
