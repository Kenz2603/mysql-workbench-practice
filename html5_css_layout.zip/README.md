# Tạo layout với các thẻ HTML5 và CSS

Bài thực hành sử dụng các thẻ HTML5 semantic:

- `header`
- `nav`
- `section`
- `article`
- `aside`
- `footer`

CSS được đặt trong `styles.css` và liên kết với `index.html`.
Layout có header, thanh điều hướng, vùng nội dung chính, sidebar và footer.
