package com.codegym.service;
import com.codegym.model.Product;
import java.util.*;

public class ProductServiceImpl implements ProductService {
    private static final Map<Integer, Product> products = new LinkedHashMap<>();
    private static int nextId = 4;
    static {
        products.put(1,new Product(1,"Laptop",1500,"Laptop văn phòng","Dell"));
        products.put(2,new Product(2,"Điện thoại",900,"Điện thoại thông minh","Samsung"));
        products.put(3,new Product(3,"Tai nghe",120,"Tai nghe không dây","Sony"));
    }
    public List<Product> findAll(){ return new ArrayList<>(products.values()); }
    public void save(Product p){ if(p.getId()==0)p.setId(nextId++); products.put(p.getId(),p); }
    public Product findById(int id){ return products.get(id); }
    public void update(int id,Product p){ p.setId(id); products.put(id,p); }
    public void remove(int id){ products.remove(id); }
    public List<Product> findByName(String name){
        List<Product> result=new ArrayList<>();
        String keyword=name==null?"":name.toLowerCase();
        for(Product p:products.values())
            if(p.getName().toLowerCase().contains(keyword)) result.add(p);
        return result;
    }
}