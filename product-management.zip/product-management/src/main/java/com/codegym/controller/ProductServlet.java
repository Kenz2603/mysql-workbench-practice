package com.codegym.controller;

import com.codegym.model.Product;
import com.codegym.service.*;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;

@WebServlet(name="ProductServlet", urlPatterns="/products")
public class ProductServlet extends HttpServlet {
    private final ProductService service=new ProductServiceImpl();

    protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        String action=req.getParameter("action"); if(action==null) action="";
        switch(action){
            case "create" -> forward(req,resp,"/product/create.jsp");
            case "edit" -> showProduct(req,resp,"/product/edit.jsp");
            case "delete" -> showProduct(req,resp,"/product/delete.jsp");
            case "view" -> showProduct(req,resp,"/product/view.jsp");
            case "search" -> search(req,resp);
            default -> list(req,resp);
        }
    }
    protected void doPost(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setCharacterEncoding("UTF-8");
        String action=req.getParameter("action"); if(action==null) action="";
        try{
            switch(action){
                case "create" -> create(req,resp);
                case "edit" -> update(req,resp);
                case "delete" -> delete(req,resp);
                default -> resp.sendRedirect(req.getContextPath()+"/products");
            }
        }catch(NumberFormatException e){
            req.setAttribute("error","Dữ liệu không hợp lệ.");
            forward(req,resp,"/error-404.jsp");
        }
    }
    private void list(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        req.setAttribute("products",service.findAll()); forward(req,resp,"/product/list.jsp");
    }
    private void search(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        String keyword=req.getParameter("keyword");
        req.setAttribute("keyword",keyword);
        req.setAttribute("products",service.findByName(keyword));
        forward(req,resp,"/product/list.jsp");
    }
    private void showProduct(HttpServletRequest req,HttpServletResponse resp,String page)throws ServletException,IOException{
        Product p=find(req);
        if(p==null){forward(req,resp,"/error-404.jsp");return;}
        req.setAttribute("product",p); forward(req,resp,page);
    }
    private void create(HttpServletRequest req,HttpServletResponse resp)throws IOException{
        Product p=new Product(0,req.getParameter("name"),Double.parseDouble(req.getParameter("price")),
                req.getParameter("description"),req.getParameter("manufacturer"));
        service.save(p); resp.sendRedirect(req.getContextPath()+"/products");
    }
    private void update(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        int id=Integer.parseInt(req.getParameter("id"));
        if(service.findById(id)==null){forward(req,resp,"/error-404.jsp");return;}
        Product p=new Product(id,req.getParameter("name"),Double.parseDouble(req.getParameter("price")),
                req.getParameter("description"),req.getParameter("manufacturer"));
        service.update(id,p); resp.sendRedirect(req.getContextPath()+"/products");
    }
    private void delete(HttpServletRequest req,HttpServletResponse resp)throws ServletException,IOException{
        Product p=find(req); if(p==null){forward(req,resp,"/error-404.jsp");return;}
        service.remove(p.getId()); resp.sendRedirect(req.getContextPath()+"/products");
    }
    private Product find(HttpServletRequest req){
        try{return service.findById(Integer.parseInt(req.getParameter("id")));}catch(Exception e){return null;}
    }
    private void forward(HttpServletRequest req,HttpServletResponse resp,String page)throws ServletException,IOException{
        req.getRequestDispatcher(page).forward(req,resp);
    }
}