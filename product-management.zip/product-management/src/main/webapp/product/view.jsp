<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<!DOCTYPE html><html><head><title>Chi tiết sản phẩm</title><style>
body{font-family:Arial,sans-serif;background:#f4f6f8;margin:30px;color:#222}
.box{max-width:1000px;margin:auto;background:#fff;padding:25px;border-radius:8px;box-shadow:0 3px 12px #0002}
h1,h2{color:#1b2a7a}table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{padding:11px;border-bottom:1px solid #ddd;text-align:left}th{background:#1b2a7a;color:white}
a{color:#1769aa}.btn{display:inline-block;padding:8px 13px;border-radius:4px;text-decoration:none;margin:2px}
.create{background:#28a745;color:white}.danger{color:#c0392b}
input,textarea{width:100%;padding:9px;margin:5px 0 13px;box-sizing:border-box}
button{padding:9px 15px;border:0;border-radius:4px;background:#1b2a7a;color:#fff;cursor:pointer}
.search{display:flex;gap:8px;margin:15px 0}.search input{margin:0}
</style></head><body><div class="box">
<h2>Chi tiết sản phẩm</h2><table>
<tr><th>ID</th><td>${product.id}</td></tr><tr><th>Tên</th><td>${product.name}</td></tr>
<tr><th>Giá</th><td>${product.price}</td></tr><tr><th>Mô tả</th><td>${product.description}</td></tr>
<tr><th>Nhà sản xuất</th><td>${product.manufacturer}</td></tr></table>
<a href="${pageContext.request.contextPath}/products">Quay lại danh sách</a>
</div></body></html>