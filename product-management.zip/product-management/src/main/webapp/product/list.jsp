<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<%@ page contentType="text/html" pageEncoding="UTF-8" %>
<!DOCTYPE html><html><head><title>Quản lý sản phẩm</title><style>
body{font-family:Arial,sans-serif;background:#f4f6f8;margin:30px;color:#222}
.box{max-width:1000px;margin:auto;background:#fff;padding:25px;border-radius:8px;box-shadow:0 3px 12px #0002}
h1,h2{color:#1b2a7a}table{width:100%;border-collapse:collapse;margin-top:20px}
th,td{padding:11px;border-bottom:1px solid #ddd;text-align:left}th{background:#1b2a7a;color:white}
a{color:#1769aa}.btn{display:inline-block;padding:8px 13px;border-radius:4px;text-decoration:none;margin:2px}
.create{background:#28a745;color:white}.danger{color:#c0392b}
input,textarea{width:100%;padding:9px;margin:5px 0 13px;box-sizing:border-box}
button{padding:9px 15px;border:0;border-radius:4px;background:#1b2a7a;color:#fff;cursor:pointer}
.search{display:flex;gap:8px;margin:15px 0}.search input{margin:0}
</style></head><body><div class="box">
<h1>Danh sách sản phẩm</h1>
<a class="btn create" href="${pageContext.request.contextPath}/products?action=create">Tạo sản phẩm mới</a>
<form class="search" action="${pageContext.request.contextPath}/products" method="get">
<input type="hidden" name="action" value="search">
<input name="keyword" value="${keyword}" placeholder="Nhập tên sản phẩm">
<button>Tìm kiếm</button>
<a class="btn" href="${pageContext.request.contextPath}/products">Tất cả</a>
</form>
<table><tr><th>ID</th><th>Tên</th><th>Giá</th><th>Mô tả</th><th>Nhà sản xuất</th><th>Hành động</th></tr>
<c:forEach items="${products}" var="p"><tr>
<td>${p.id}</td><td><c:out value="${p.name}"/></td><td>${p.price}</td>
<td><c:out value="${p.description}"/></td><td><c:out value="${p.manufacturer}"/></td>
<td><a href="${pageContext.request.contextPath}/products?action=view&id=${p.id}">Xem</a> |
<a href="${pageContext.request.contextPath}/products?action=edit&id=${p.id}">Sửa</a> |
<a class="danger" href="${pageContext.request.contextPath}/products?action=delete&id=${p.id}">Xóa</a></td>
</tr></c:forEach>
</table></div></body></html>