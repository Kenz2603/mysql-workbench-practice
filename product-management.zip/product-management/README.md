# Product Management

Ứng dụng quản lý sản phẩm theo kiến trúc MVC.

## Chức năng
- Hiển thị danh sách sản phẩm
- Tạo sản phẩm
- Cập nhật sản phẩm
- Xóa sản phẩm
- Xem chi tiết
- Tìm kiếm theo tên

## Công nghệ
Java 17, Maven, Jakarta Servlet/JSP/JSTL, Tomcat 10.1+.

## Build
```bash
mvn clean package
```

Deploy `target/product-management.war` lên Tomcat và truy cập:
`http://localhost:8080/product-management/products`
