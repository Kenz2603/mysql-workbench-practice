# iNotes - Strategy Pattern

Bài thực hành Java Web quản lý ghi chú, cho phép chuyển tầng lưu trữ giữa **MySQL** và **File TXT** tại runtime bằng Strategy Pattern.

## Chức năng
- Danh sách ghi chú
- Thêm, xem, sửa, xóa
- Tìm kiếm theo tiêu đề hoặc nội dung
- Phân loại: Cá nhân / Công việc / Học tập
- `NoteStrategy`
- `NoteDBStrategy` dùng JDBC + MySQL
- `NoteFileStrategy` dùng định dạng `id|title|content|typeId`
- `NoteManagement.setStrategy(...)` để đổi storage lúc runtime

## Chạy
1. Chạy `database.sql` trong MySQL.
2. Sửa `JDBC_PASSWORD` trong `NoteDBStrategy.java`.
3. Build:
   `mvn clean package`
4. Deploy `target/inotes.war` vào Tomcat 10.1+.
5. Truy cập:
   `http://localhost:8080/inotes/notes`

Khi chọn **File TXT**, dữ liệu được lưu tại:
`<user.home>/inotes-data/notes.txt`

## Nộp bài
Đẩy toàn bộ thư mục dự án này lên GitHub và nộp link repository.
