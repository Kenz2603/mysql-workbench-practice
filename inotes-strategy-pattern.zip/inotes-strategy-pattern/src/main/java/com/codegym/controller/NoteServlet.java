package com.codegym.controller;

import com.codegym.model.Note;
import com.codegym.service.NoteManagement;
import com.codegym.strategy.NoteDBStrategy;
import com.codegym.strategy.NoteFileStrategy;
import com.codegym.strategy.NoteStrategy;
import jakarta.servlet.*;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/notes")
public class NoteServlet extends HttpServlet {
    private NoteManagement management;

    @Override
    public void init() {
        management = new NoteManagement(new NoteDBStrategy());
    }

    private void chooseStrategy(HttpServletRequest request) {
        String storage = request.getParameter("storage");
        if ("file".equalsIgnoreCase(storage)) {
            String path = Paths.get(System.getProperty("user.home"), "inotes-data", "notes.txt").toString();
            management.setStrategy(new NoteFileStrategy(path));
            request.getSession().setAttribute("storage", "file");
        } else if ("db".equalsIgnoreCase(storage)) {
            management.setStrategy(new NoteDBStrategy());
            request.getSession().setAttribute("storage", "db");
        } else {
            Object current = request.getSession().getAttribute("storage");
            if ("file".equals(current)) {
                String path = Paths.get(System.getProperty("user.home"), "inotes-data", "notes.txt").toString();
                management.setStrategy(new NoteFileStrategy(path));
            } else {
                management.setStrategy(new NoteDBStrategy());
            }
        }
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        chooseStrategy(request);
        String action = request.getParameter("action");
        if (action == null) action = "list";
        try {
            switch (action) {
                case "create" -> request.getRequestDispatcher("/note/create.jsp").forward(request, response);
                case "delete" -> {
                    management.deleteNote(Integer.parseInt(request.getParameter("id")));
                    response.sendRedirect("notes");
                }
                case "edit" -> showEdit(request, response);
                case "view" -> showView(request, response);
                default -> list(request, response);
            }
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }

    private Note findById(int id) throws SQLException {
        return management.findAll().stream().filter(n -> n.getId() == id).findFirst().orElse(null);
    }

    private void showEdit(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        request.setAttribute("note", findById(Integer.parseInt(request.getParameter("id"))));
        request.getRequestDispatcher("/note/edit.jsp").forward(request, response);
    }

    private void showView(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        request.setAttribute("note", findById(Integer.parseInt(request.getParameter("id"))));
        request.getRequestDispatcher("/note/view.jsp").forward(request, response);
    }

    private void list(HttpServletRequest request, HttpServletResponse response)
            throws SQLException, ServletException, IOException {
        String keyword = request.getParameter("keyword");
        List<Note> notes = management.searchNotes(keyword);
        request.setAttribute("notes", notes);
        request.setAttribute("keyword", keyword == null ? "" : keyword);
        request.getRequestDispatcher("/note/list.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        chooseStrategy(request);
        String action = request.getParameter("action");
        try {
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            int typeId = Integer.parseInt(request.getParameter("typeId"));
            if ("edit".equals(action)) {
                management.updateNote(Integer.parseInt(request.getParameter("id")), title, content, typeId);
            } else {
                management.addNote(title, content, typeId);
            }
            response.sendRedirect("notes");
        } catch (SQLException e) {
            throw new ServletException(e);
        }
    }
}
