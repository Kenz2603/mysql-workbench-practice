package com.codegym.service;

import com.codegym.model.Note;
import com.codegym.strategy.NoteStrategy;
import java.sql.SQLException;
import java.util.List;

public class NoteManagement {
    private NoteStrategy strategy;

    public NoteManagement(NoteStrategy strategy) { this.strategy = strategy; }
    public void setStrategy(NoteStrategy strategy) { this.strategy = strategy; }

    public List<Note> searchNotes(String keyword) throws SQLException {
        return (keyword == null || keyword.isBlank()) ? strategy.findAll() : strategy.search(keyword.trim());
    }

    public void addNote(String title, String content, int typeId) throws SQLException {
        Note note = new Note(title, content, typeId);
        note.setStrategy(strategy);
        note.save();
    }

    public void updateNote(int id, String title, String content, int typeId) throws SQLException {
        Note note = new Note(id, title, content, typeId);
        note.setStrategy(strategy);
        note.save();
    }

    public void deleteNote(int id) throws SQLException {
        strategy.delete(id);
    }

    public List<Note> findAll() throws SQLException { return strategy.findAll(); }
}
