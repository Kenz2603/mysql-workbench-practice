package com.codegym.strategy;

import com.codegym.model.Note;
import java.sql.SQLException;
import java.util.List;

public interface NoteStrategy {
    void save(Note note) throws SQLException;
    void delete(int id) throws SQLException;
    List<Note> findAll() throws SQLException;
    List<Note> search(String keyword) throws SQLException;
}
