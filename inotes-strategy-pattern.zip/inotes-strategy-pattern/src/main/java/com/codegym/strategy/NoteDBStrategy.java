package com.codegym.strategy;

import com.codegym.model.Note;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class NoteDBStrategy implements NoteStrategy {
    private static final String JDBC_URL =
            "jdbc:mysql://localhost:3306/inotes_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String JDBC_USER = "root";
    private static final String JDBC_PASSWORD = "password"; // Đổi theo MySQL của bạn

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(JDBC_URL, JDBC_USER, JDBC_PASSWORD);
    }

    @Override
    public void save(Note note) throws SQLException {
        if (note.getId() == 0) {
            String sql = "INSERT INTO notes(title, content, type_id) VALUES (?, ?, ?)";
            try (Connection c = getConnection();
                 PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
                ps.setString(1, note.getTitle());
                ps.setString(2, note.getContent());
                ps.setInt(3, note.getTypeId());
                ps.executeUpdate();
                try (ResultSet rs = ps.getGeneratedKeys()) {
                    if (rs.next()) note.setId(rs.getInt(1));
                }
            }
        } else {
            String sql = "UPDATE notes SET title=?, content=?, type_id=? WHERE id=?";
            try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
                ps.setString(1, note.getTitle());
                ps.setString(2, note.getContent());
                ps.setInt(3, note.getTypeId());
                ps.setInt(4, note.getId());
                ps.executeUpdate();
            }
        }
    }

    @Override
    public void delete(int id) throws SQLException {
        try (Connection c = getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM notes WHERE id=?")) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private List<Note> query(String sql, String keyword) throws SQLException {
        List<Note> list = new ArrayList<>();
        try (Connection c = getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            if (keyword != null) {
                String k = "%" + keyword + "%";
                ps.setString(1, k);
                ps.setString(2, k);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(new Note(rs.getInt("id"), rs.getString("title"),
                            rs.getString("content"), rs.getInt("type_id"), rs.getString("type_name")));
                }
            }
        }
        return list;
    }

    @Override
    public List<Note> findAll() throws SQLException {
        return query("SELECT n.id,n.title,n.content,n.type_id,t.name AS type_name " +
                "FROM notes n LEFT JOIN note_type t ON n.type_id=t.id ORDER BY n.id DESC", null);
    }

    @Override
    public List<Note> search(String keyword) throws SQLException {
        return query("SELECT n.id,n.title,n.content,n.type_id,t.name AS type_name " +
                "FROM notes n LEFT JOIN note_type t ON n.type_id=t.id " +
                "WHERE n.title LIKE ? OR n.content LIKE ? ORDER BY n.id DESC", keyword);
    }
}
