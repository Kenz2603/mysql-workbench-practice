package com.codegym.strategy;

import com.codegym.model.Note;
import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.sql.SQLException;
import java.util.*;

public class NoteFileStrategy implements NoteStrategy {
    private final Path file;

    public NoteFileStrategy(String path) {
        this.file = Paths.get(path);
    }

    private String clean(String value) {
        return value == null ? "" : value.replace("|", "/").replace("\r", " ").replace("\n", "\\n");
    }

    private List<Note> readAll() throws IOException {
        List<Note> notes = new ArrayList<>();
        if (!Files.exists(file)) return notes;
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            if (line.isBlank()) continue;
            String[] p = line.split("\\|", -1);
            if (p.length >= 4) {
                notes.add(new Note(Integer.parseInt(p[0]), p[1],
                        p[2].replace("\\n", "\n"), Integer.parseInt(p[3])));
            }
        }
        return notes;
    }

    private void writeAll(List<Note> notes) throws IOException {
        if (file.getParent() != null) Files.createDirectories(file.getParent());
        List<String> lines = new ArrayList<>();
        for (Note n : notes) {
            lines.add(n.getId() + "|" + clean(n.getTitle()) + "|" + clean(n.getContent()) + "|" + n.getTypeId());
        }
        Files.write(file, lines, StandardCharsets.UTF_8,
                StandardOpenOption.CREATE, StandardOpenOption.TRUNCATE_EXISTING);
    }

    @Override
    public void save(Note note) throws SQLException {
        try {
            List<Note> notes = readAll();
            if (note.getId() == 0) {
                int nextId = notes.stream().mapToInt(Note::getId).max().orElse(0) + 1;
                note.setId(nextId);
                notes.add(note);
            } else {
                notes.removeIf(n -> n.getId() == note.getId());
                notes.add(note);
            }
            writeAll(notes);
        } catch (IOException e) {
            throw new SQLException("Không thể lưu file notes", e);
        }
    }

    @Override
    public void delete(int id) throws SQLException {
        try {
            List<Note> notes = readAll();
            notes.removeIf(n -> n.getId() == id);
            writeAll(notes);
        } catch (IOException e) {
            throw new SQLException("Không thể xóa note trong file", e);
        }
    }

    @Override
    public List<Note> findAll() throws SQLException {
        try { return readAll(); }
        catch (IOException e) { throw new SQLException("Không thể đọc file notes", e); }
    }

    @Override
    public List<Note> search(String keyword) throws SQLException {
        String k = keyword == null ? "" : keyword.toLowerCase();
        List<Note> result = new ArrayList<>();
        for (Note n : findAll()) {
            if (n.getTitle().toLowerCase().contains(k) ||
                    (n.getContent() != null && n.getContent().toLowerCase().contains(k))) {
                result.add(n);
            }
        }
        return result;
    }
}
