<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Thêm ghi chú</title><style>body{font-family:Arial;max-width:760px;margin:35px auto;background:#f6f7fb}.card{background:#fff;padding:25px;border-radius:10px}label{display:block;margin-top:15px;font-weight:bold}input,select,textarea{width:100%;box-sizing:border-box;padding:10px;margin-top:5px}button,a{display:inline-block;margin-top:18px;padding:10px 16px;text-decoration:none}button{background:#2563eb;color:#fff;border:0;border-radius:6px}</style></head>
<body><div class="card"><h2>Thêm Mới Ghi Chú</h2>
<form method="post" action="notes"><input type="hidden" name="action" value="create">
<label>Tiêu đề</label><input name="title" required>
<label>Phân loại</label><select name="typeId"><option value="1">Cá nhân</option><option value="2">Công việc</option><option value="3">Học tập</option></select>
<label>Nội dung</label><textarea name="content" rows="8"></textarea>
<button type="submit">Lưu Ghi Chú</button> <a href="notes">Hủy bỏ</a>
</form></div></body></html>