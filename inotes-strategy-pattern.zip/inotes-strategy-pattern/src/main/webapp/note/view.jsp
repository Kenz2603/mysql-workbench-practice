<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Xem ghi chú</title><style>body{font-family:Arial;max-width:760px;margin:35px auto;background:#f6f7fb}.card{background:#fff;padding:25px;border-radius:10px}label{display:block;margin-top:15px;font-weight:bold}input,select,textarea{width:100%;box-sizing:border-box;padding:10px;margin-top:5px}button,a{display:inline-block;margin-top:18px;padding:10px 16px;text-decoration:none}button{background:#2563eb;color:#fff;border:0;border-radius:6px}</style></head>
<body><div class="card"><h2><c:out value="${note.title}"/></h2>
<p><b>Phân loại:</b> <c:out value="${empty note.typeName ? note.typeId : note.typeName}"/></p>
<p style="white-space:pre-wrap"><c:out value="${note.content}"/></p>
<a href="notes">← Quay lại danh sách</a></div></body></html>