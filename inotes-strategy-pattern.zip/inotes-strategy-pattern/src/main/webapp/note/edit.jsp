<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>Sửa ghi chú</title><style>body{font-family:Arial;max-width:760px;margin:35px auto;background:#f6f7fb}.card{background:#fff;padding:25px;border-radius:10px}label{display:block;margin-top:15px;font-weight:bold}input,select,textarea{width:100%;box-sizing:border-box;padding:10px;margin-top:5px}button,a{display:inline-block;margin-top:18px;padding:10px 16px;text-decoration:none}button{background:#2563eb;color:#fff;border:0;border-radius:6px}</style></head>
<body><div class="card"><h2>Sửa Ghi Chú</h2>
<form method="post" action="notes"><input type="hidden" name="action" value="edit"><input type="hidden" name="id" value="${note.id}">
<label>Tiêu đề</label><input name="title" value="<c:out value='${note.title}'/>" required>
<label>Phân loại</label><select name="typeId">
<option value="1" ${note.typeId==1?'selected':''}>Cá nhân</option><option value="2" ${note.typeId==2?'selected':''}>Công việc</option><option value="3" ${note.typeId==3?'selected':''}>Học tập</option>
</select><label>Nội dung</label><textarea name="content" rows="8"><c:out value="${note.content}"/></textarea>
<button type="submit">Cập nhật</button> <a href="notes">Hủy bỏ</a></form></div></body></html>