<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html><html><head><meta charset="UTF-8"><title>iNotes</title>
<style>
body{font-family:Arial;max-width:1000px;margin:35px auto;background:#f6f7fb;color:#222}
.card{background:white;padding:24px;border-radius:10px;box-shadow:0 2px 10px #ddd}
.top{display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap}
input,select,textarea,button,.btn{padding:9px;border:1px solid #ccc;border-radius:6px}
.btn{background:#2563eb;color:white;text-decoration:none;border:0}.danger{background:#dc2626}
table{width:100%;border-collapse:collapse;margin-top:20px}th,td{padding:12px;border-bottom:1px solid #ddd;text-align:left}
</style></head><body><div class="card">
<h1>iNotes Dashboard</h1>
<div class="top">
<form method="get" action="notes"><input name="keyword" value="${keyword}" placeholder="Tìm tiêu đề hoặc nội dung">
<button type="submit">Tìm kiếm</button></form>
<div>
<a class="btn" href="notes?action=create">+ Thêm mới</a>
<a class="btn" href="notes?storage=db">MySQL</a>
<a class="btn" href="notes?storage=file">File TXT</a>
</div></div>
<p>Storage hiện tại: <b>${empty sessionScope.storage ? 'db' : sessionScope.storage}</b></p>
<table><tr><th>#</th><th>Tiêu đề</th><th>Phân loại</th><th>Thao tác</th></tr>
<c:forEach items="${notes}" var="n">
<tr><td>${n.id}</td><td><c:out value="${n.title}"/></td>
<td><c:out value="${empty n.typeName ? n.typeId : n.typeName}"/></td>
<td><a href="notes?action=view&id=${n.id}">Xem</a> |
<a href="notes?action=edit&id=${n.id}">Sửa</a> |
<a href="notes?action=delete&id=${n.id}" onclick="return confirm('Xóa ghi chú này?')">Xóa</a></td></tr>
</c:forEach></table>
</div></body></html>