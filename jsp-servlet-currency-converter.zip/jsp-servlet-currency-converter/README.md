# jsp-servlet-currency-converter

Ứng dụng Servlet chuyển đổi USD sang VNĐ theo tỉ giá người dùng nhập.

## Công thức
`VND = USD × Rate`

## Công nghệ
- Java 17
- Maven
- Jakarta Servlet API 6.0
- JSP API 3.1.1
- Tomcat 10.1+

## Build
```bash
mvn clean package
```

File WAR sau khi build:
`target/jsp-servlet-currency-converter.war`

Sau khi deploy:
`http://localhost:8080/jsp-servlet-currency-converter/`
