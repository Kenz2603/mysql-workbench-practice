# Product Discount Calculator

Ứng dụng Java Web tính chiết khấu sản phẩm.

Công thức:

`Discount Amount = List Price * Discount Percent * 0.01`

`Discount Price = List Price - Discount Amount`

## Công nghệ
Java 17, Maven, Jakarta Servlet 6.0, JSP 3.1.1, Tomcat 10.1+.

## Build
```bash
mvn clean package
```

WAR:
`target/product-discount-calculator.war`

Sau khi deploy:
`http://localhost:8080/product-discount-calculator/`
