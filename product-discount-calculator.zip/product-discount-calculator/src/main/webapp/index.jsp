<%@page contentType="text/html" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Product Discount Calculator</title>
    <style>
        body { font-family: Arial, sans-serif; background: #f4f6f8; display: flex; justify-content: center; margin-top: 70px; }
        .container { width: 400px; background: white; padding: 35px; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,.12); }
        h2 { text-align: center; color: #1b2a7a; }
        label { display: block; margin-top: 15px; font-weight: bold; }
        input { width: 100%; padding: 10px; margin-top: 6px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { width: 100%; margin-top: 22px; padding: 12px; background: #1b2a7a; color: white; border: 0; border-radius: 4px; cursor: pointer; font-weight: bold; }
        button:hover { background: #121c54; }
    </style>
</head>
<body>
<div class="container">
    <h2>Product Discount Calculator</h2>

    <form action="display-discount" method="POST">
        <label>Product Description:</label>
        <input type="text" name="productDescription" required>

        <label>List Price:</label>
        <input type="number" name="listPrice" min="0" step="any" required>

        <label>Discount Percent:</label>
        <input type="number" name="discountPercent" min="0" step="any" required>

        <button type="submit">Calculate Discount</button>
    </form>
</div>
</body>
</html>
