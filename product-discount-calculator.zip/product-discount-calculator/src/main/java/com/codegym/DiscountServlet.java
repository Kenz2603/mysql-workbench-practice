package com.codegym;

import java.io.IOException;
import java.io.PrintWriter;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "DiscountServlet", urlPatterns = {"/display-discount"})
public class DiscountServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String description = request.getParameter("productDescription");

        try (PrintWriter out = response.getWriter()) {
            try {
                double listPrice = Double.parseDouble(request.getParameter("listPrice"));
                double discountPercent = Double.parseDouble(request.getParameter("discountPercent"));

                double discountAmount = listPrice * discountPercent * 0.01;
                double discountPrice = listPrice - discountAmount;

                out.println("<!DOCTYPE html>");
                out.println("<html lang='vi'>");
                out.println("<head><meta charset='UTF-8'><title>Discount Result</title></head>");
                out.println("<body style='font-family:Arial,sans-serif;background:#f4f6f8;text-align:center;margin-top:70px;'>");
                out.println("<div style='display:inline-block;background:white;padding:35px 50px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,.12);'>");
                out.println("<h2 style='color:#1b2a7a;'>DISCOUNT RESULT</h2>");
                out.println("<p><strong>Product Description:</strong> " + description + "</p>");
                out.printf("<p><strong>List Price:</strong> %.2f</p>%n", listPrice);
                out.printf("<p><strong>Discount Percent:</strong> %.2f%%</p>%n", discountPercent);
                out.printf("<p><strong>Discount Amount:</strong> %.2f</p>%n", discountAmount);
                out.printf("<h3 style='color:#27ae60;'>Discount Price: %.2f</h3>%n", discountPrice);
                out.println("<br><a href='index.jsp' style='text-decoration:none;background:#1b2a7a;color:white;padding:10px 20px;border-radius:4px;'>Back</a>");
                out.println("</div></body></html>");
            } catch (NumberFormatException e) {
                out.println("<h2 style='color:red;text-align:center;'>Invalid price or discount percent.</h2>");
                out.println("<div style='text-align:center;'><a href='index.jsp'>Back</a></div>");
            }
        }
    }
}
