# Hiển thị danh sách khách hàng - JSP/JSTL

Bài thực hành hiển thị danh sách khách hàng gồm:
- Tên
- Ngày sinh
- Địa chỉ
- Ảnh

Trang `index.jsp` tạo danh sách khách hàng có sẵn và dùng JSTL Core (`c:forEach`, `c:out`) để hiển thị.

## Môi trường
- Java 17
- Maven
- Tomcat 10.1+
- Jakarta JSTL 3.x

## Chạy
```bash
mvn clean package
```

Deploy `target/customer-list-jstl.war` lên Tomcat, sau đó truy cập:
`http://localhost:8080/customer-list-jstl/`

> Ghi chú: đề bài minh họa URI JSTL cũ `http://java.sun.com/jsp/jstl/core`.
> Dự án này dùng Tomcat 10.1+/Jakarta nên sử dụng URI `jakarta.tags.core`.
