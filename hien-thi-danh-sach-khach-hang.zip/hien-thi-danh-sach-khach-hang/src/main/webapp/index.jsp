<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="jakarta.tags.core" %>
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <title>Danh sách khách hàng</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 40px; background: #f5f5f5; }
        h1 { text-align: center; }
        table { width: 850px; max-width: 100%; margin: auto; border-collapse: collapse; background: white; }
        th, td { border: 1px solid #999; padding: 10px; text-align: center; }
        th { background: #e8e8e8; }
        img { width: 100px; height: 100px; object-fit: cover; }
    </style>
</head>
<body>
<h1>Danh sách khách hàng</h1>

<%
    java.util.List<java.util.Map<String, String>> customers = new java.util.ArrayList<>();

    java.util.Map<String, String> c1 = new java.util.HashMap<>();
    c1.put("name", "Nguyễn Văn An");
    c1.put("birthday", "10/10/1990");
    c1.put("address", "Hà Nội");
    c1.put("image", "https://i.pravatar.cc/150?img=12");
    customers.add(c1);

    java.util.Map<String, String> c2 = new java.util.HashMap<>();
    c2.put("name", "Trần Thị Bình");
    c2.put("birthday", "15/05/1992");
    c2.put("address", "Đà Nẵng");
    c2.put("image", "https://i.pravatar.cc/150?img=47");
    customers.add(c2);

    java.util.Map<String, String> c3 = new java.util.HashMap<>();
    c3.put("name", "Lê Minh Cường");
    c3.put("birthday", "20/08/1988");
    c3.put("address", "TP. Hồ Chí Minh");
    c3.put("image", "https://i.pravatar.cc/150?img=11");
    customers.add(c3);

    java.util.Map<String, String> c4 = new java.util.HashMap<>();
    c4.put("name", "Phạm Thu Dung");
    c4.put("birthday", "02/12/1995");
    c4.put("address", "Hải Phòng");
    c4.put("image", "https://i.pravatar.cc/150?img=44");
    customers.add(c4);

    request.setAttribute("customers", customers);
%>

<table>
    <thead>
    <tr>
        <th>Tên</th>
        <th>Ngày sinh</th>
        <th>Địa chỉ</th>
        <th>Ảnh</th>
    </tr>
    </thead>
    <tbody>
    <c:forEach var="customer" items="${customers}">
        <tr>
            <td><c:out value="${customer.name}"/></td>
            <td><c:out value="${customer.birthday}"/></td>
            <td><c:out value="${customer.address}"/></td>
            <td><img src="${customer.image}" alt="${customer.name}"></td>
        </tr>
    </c:forEach>
    </tbody>
</table>
</body>
</html>
